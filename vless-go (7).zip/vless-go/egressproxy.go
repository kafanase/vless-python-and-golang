package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

// EgressProxyConfig — настройки исходящего (egress) апстрим-прокси, через
// который сервер сам подключается к destination вместо прямого dial.
// Включается администратором по желанию (по умолчанию выключено).
type EgressProxyConfig struct {
	Enabled      bool
	Protocol     string // "socks5" | "socks4" | "http" | "https"
	Scope        string // "all" | "cloudflare_only"
	Host         string
	Port         int
	TLS          bool   // обернуть соединение с прокси в TLS перед протоколом
	TLSSNI       string // необязательное переопределение ServerName для TLS к прокси
	TLSCAFile    string // путь к PEM с доверенным CA/самоподписанным сертификатом
	TLSPinSHA256 string // hex SHA-256 отпечаток сертификата прокси (pinning)
	Username     string
	Password     string
}

func loadEgressProxyConfig(cfg map[string]any) (*EgressProxyConfig, error) {
	enabled := toBool(cfg["enabled"], false)
	if !enabled {
		return &EgressProxyConfig{Enabled: false}, nil
	}
	protocol := strings.ToLower(toStr(cfg["protocol"], ""))
	switch protocol {
	case "socks5", "socks4", "http", "https":
	default:
		return nil, configErrorf("egress_proxy.protocol должен быть socks5, socks4, http или https")
	}
	host := toStr(cfg["host"], "")
	if host == "" {
		return nil, configErrorf("egress_proxy.host обязателен, если egress_proxy.enabled=true")
	}
	port := toInt(cfg["port"], 0)
	if port < 1 || port > 65535 {
		return nil, configErrorf("egress_proxy.port вне диапазона 1..65535")
	}
	scope := strings.ToLower(toStr(cfg["scope"], "all"))
	if scope != "all" && scope != "cloudflare_only" {
		return nil, configErrorf("egress_proxy.scope должен быть all или cloudflare_only")
	}
	useTLS := toBool(cfg["tls"], protocol == "https")
	pin := strings.ToLower(strings.ReplaceAll(toStr(cfg["tls_pin_sha256"], ""), ":", ""))
	if pin != "" {
		if _, err := hex.DecodeString(pin); err != nil || len(pin) != 64 {
			return nil, configErrorf("egress_proxy.tls_pin_sha256 должен быть hex SHA-256 (64 символа, опционально через ':')")
		}
	}
	return &EgressProxyConfig{
		Enabled:      true,
		Protocol:     protocol,
		Scope:        scope,
		Host:         host,
		Port:         port,
		TLS:          useTLS,
		TLSSNI:       toStr(cfg["tls_sni"], host),
		TLSCAFile:    toStr(cfg["tls_ca_file"], ""),
		TLSPinSHA256: pin,
		Username:     toStr(cfg["username"], ""),
		Password:     toStr(cfg["password"], ""),
	}, nil
}

// buildProxyTLSConfig собирает tls.Config для соединения с самим
// апстрим-прокси (egress_proxy.tls: true). По умолчанию — обычная
// проверка сертификата по системному трастстору. Если задан tls_ca_file —
// проверка идёт по указанному CA/самоподписанному сертификату вместо
// системного пула. Если задан tls_pin_sha256 — обычная проверка цепочки и
// имени отключается полностью, вместо неё сверяется SHA-256 отпечаток
// сертификата, который прислал прокси (годится для самоподписанных
// сертификатов без корректного SAN/CN — частый случай для приватных
// SOCKS5S-серверов).
func buildProxyTLSConfig(cfg *EgressProxyConfig) (*tls.Config, error) {
	tlsCfg := &tls.Config{
		ServerName: cfg.TLSSNI,
		MinVersion: tls.VersionTLS12,
	}
	if cfg.TLSCAFile != "" {
		pemBytes, err := os.ReadFile(cfg.TLSCAFile)
		if err != nil {
			return nil, fmt.Errorf("egress_proxy.tls_ca_file: %w", err)
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(pemBytes) {
			return nil, fmt.Errorf("egress_proxy.tls_ca_file: не удалось разобрать PEM %s", cfg.TLSCAFile)
		}
		tlsCfg.RootCAs = pool
	}
	if cfg.TLSPinSHA256 != "" {
		expected, err := hex.DecodeString(cfg.TLSPinSHA256)
		if err != nil || len(expected) != sha256.Size {
			return nil, fmt.Errorf("egress_proxy.tls_pin_sha256: неверный формат")
		}
		// Стандартная проверка цепочки/имени отключается — вместо неё
		// самостоятельно сверяем отпечаток в VerifyPeerCertificate.
		tlsCfg.InsecureSkipVerify = true
		tlsCfg.VerifyPeerCertificate = func(rawCerts [][]byte, _ [][]*x509.Certificate) error {
			if len(rawCerts) == 0 {
				return errors.New("сертификат egress-прокси не предоставлен")
			}
			sum := sha256.Sum256(rawCerts[0])
			if subtle.ConstantTimeCompare(sum[:], expected) != 1 {
				return fmt.Errorf("сертификат egress-прокси не совпадает с egress_proxy.tls_pin_sha256 (получено %x)", sum)
			}
			return nil
		}
	}
	return tlsCfg, nil
}

// dialViaEgressProxy устанавливает TCP-соединение с destination через
// сконфигурированный апстрим-прокси. targetHost может быть доменом или IP —
// резолвинг домена (если нужен протоколом) выполняется на стороне прокси,
// за исключением классического SOCKS4 без 4a-расширения для IP-адресов.
func dialViaEgressProxy(ctx context.Context, cfg *EgressProxyConfig, targetHost string, targetPort uint16, timeout time.Duration) (net.Conn, error) {
	dialer := net.Dialer{Timeout: timeout}
	proxyAddr := net.JoinHostPort(cfg.Host, fmt.Sprintf("%d", cfg.Port))
	raw, err := dialer.DialContext(ctx, "tcp", proxyAddr)
	if err != nil {
		return nil, fmt.Errorf("не удалось подключиться к egress-прокси %s: %w", proxyAddr, err)
	}

	var conn net.Conn = raw
	if cfg.TLS {
		tlsCfg, err := buildProxyTLSConfig(cfg)
		if err != nil {
			raw.Close()
			return nil, err
		}
		tlsConn := tls.Client(raw, tlsCfg)
		hsCtx, cancel := context.WithTimeout(ctx, timeout)
		defer cancel()
		if err := tlsConn.HandshakeContext(hsCtx); err != nil {
			raw.Close()
			return nil, fmt.Errorf("TLS-handshake с egress-прокси %s: %w", proxyAddr, err)
		}
		conn = tlsConn
	}

	_ = conn.SetDeadline(time.Now().Add(timeout))
	defer conn.SetDeadline(time.Time{})

	switch cfg.Protocol {
	case "http", "https":
		err = httpConnectHandshake(conn, cfg, targetHost, targetPort)
	case "socks5":
		err = socks5Handshake(conn, cfg, targetHost, targetPort)
	case "socks4":
		err = socks4Handshake(conn, targetHost, targetPort)
	default:
		err = fmt.Errorf("неизвестный протокол egress-прокси: %s", cfg.Protocol)
	}
	if err != nil {
		conn.Close()
		return nil, err
	}
	return conn, nil
}

// ---------- HTTP(S) CONNECT ----------

func httpConnectHandshake(conn net.Conn, cfg *EgressProxyConfig, host string, port uint16) error {
	target := net.JoinHostPort(host, fmt.Sprintf("%d", port))
	var req bytes.Buffer
	fmt.Fprintf(&req, "CONNECT %s HTTP/1.1\r\n", target)
	fmt.Fprintf(&req, "Host: %s\r\n", target)
	if cfg.Username != "" {
		token := base64.StdEncoding.EncodeToString([]byte(cfg.Username + ":" + cfg.Password))
		fmt.Fprintf(&req, "Proxy-Authorization: Basic %s\r\n", token)
	}
	req.WriteString("\r\n")
	if _, err := conn.Write(req.Bytes()); err != nil {
		return fmt.Errorf("CONNECT запрос к egress-прокси: %w", err)
	}

	reader := bufio.NewReader(conn)
	statusLine, err := reader.ReadString('\n')
	if err != nil {
		return fmt.Errorf("ответ CONNECT от egress-прокси: %w", err)
	}
	parts := strings.SplitN(strings.TrimSpace(statusLine), " ", 3)
	if len(parts) < 2 || !strings.HasPrefix(parts[1], "2") {
		return fmt.Errorf("egress-прокси отклонил CONNECT: %s", strings.TrimSpace(statusLine))
	}
	// Дочитываем заголовки ответа до пустой строки.
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			return fmt.Errorf("заголовки CONNECT от egress-прокси: %w", err)
		}
		if strings.TrimSpace(line) == "" {
			break
		}
	}
	return nil
}

// ---------- SOCKS5 (RFC 1928/1929) ----------

func socks5Handshake(conn net.Conn, cfg *EgressProxyConfig, host string, port uint16) error {
	if err := socks5GreetAndAuth(conn, cfg); err != nil {
		return err
	}
	_, _, err := socks5Request(conn, 0x01, host, port) // CMD=CONNECT
	return err
}

// socks5GreetAndAuth выполняет приветствие и (если нужно) аутентификацию
// SOCKS5 — общая часть для CONNECT и UDP ASSOCIATE.
func socks5GreetAndAuth(conn net.Conn, cfg *EgressProxyConfig) error {
	methods := []byte{0x00} // no-auth
	if cfg.Username != "" {
		methods = []byte{0x02, 0x00}
	}
	greeting := append([]byte{0x05, byte(len(methods))}, methods...)
	if _, err := conn.Write(greeting); err != nil {
		return fmt.Errorf("SOCKS5 greeting: %w", err)
	}
	reply := make([]byte, 2)
	if _, err := ioReadFull(conn, reply); err != nil {
		return fmt.Errorf("SOCKS5 greeting ответ: %w", err)
	}
	if reply[0] != 0x05 {
		return fmt.Errorf("egress-прокси не отвечает как SOCKS5")
	}
	switch reply[1] {
	case 0x00:
		// без аутентификации
	case 0x02:
		if err := socks5UserPassAuth(conn, cfg); err != nil {
			return err
		}
	default:
		return fmt.Errorf("egress-прокси не поддерживает подходящий метод SOCKS5-аутентификации")
	}
	return nil
}

// socks5Request отправляет команду (CONNECT=0x01, BIND=0x02, UDP
// ASSOCIATE=0x03) с адресом host:port и разбирает ответ, возвращая
// BND.ADDR/BND.PORT из ответа сервера (нужны для UDP ASSOCIATE; для CONNECT
// вызывающий код их обычно игнорирует).
func socks5Request(conn net.Conn, cmd byte, host string, port uint16) (bndHost string, bndPort uint16, err error) {
	addrBytes, err := socks5EncodeAddress(host)
	if err != nil {
		return "", 0, err
	}
	req := make([]byte, 0, 4+len(addrBytes)+2)
	req = append(req, 0x05, cmd, 0x00) // VER, CMD, RSV
	req = append(req, addrBytes...)
	req = append(req, byte(port>>8), byte(port))
	if _, err := conn.Write(req); err != nil {
		return "", 0, fmt.Errorf("SOCKS5 запрос (cmd=%d): %w", cmd, err)
	}

	header := make([]byte, 4)
	if _, err := ioReadFull(conn, header); err != nil {
		return "", 0, fmt.Errorf("SOCKS5 ответ (cmd=%d): %w", cmd, err)
	}
	if header[1] != 0x00 {
		return "", 0, fmt.Errorf("SOCKS5 egress-прокси отклонил команду %d: код %d", cmd, header[1])
	}

	var addrLen int
	switch header[3] {
	case 0x01:
		addrLen = 4
	case 0x03:
		lenB := make([]byte, 1)
		if _, err := ioReadFull(conn, lenB); err != nil {
			return "", 0, err
		}
		addrLen = int(lenB[0])
	case 0x04:
		addrLen = 16
	default:
		return "", 0, fmt.Errorf("SOCKS5: неизвестный тип адреса в ответе: %d", header[3])
	}
	addrPort := make([]byte, addrLen+2)
	if _, err := ioReadFull(conn, addrPort); err != nil {
		return "", 0, fmt.Errorf("SOCKS5 ответ (адрес, cmd=%d): %w", cmd, err)
	}
	switch header[3] {
	case 0x01, 0x04:
		bndHost = net.IP(addrPort[:addrLen]).String()
	case 0x03:
		bndHost = string(addrPort[:addrLen])
	}
	bndPort = uint16(addrPort[addrLen])<<8 | uint16(addrPort[addrLen+1])
	return bndHost, bndPort, nil
}

func socks5UserPassAuth(conn net.Conn, cfg *EgressProxyConfig) error {
	if len(cfg.Username) > 255 || len(cfg.Password) > 255 {
		return fmt.Errorf("SOCKS5: логин/пароль слишком длинные (макс. 255 байт)")
	}
	req := []byte{0x01, byte(len(cfg.Username))}
	req = append(req, cfg.Username...)
	req = append(req, byte(len(cfg.Password)))
	req = append(req, cfg.Password...)
	if _, err := conn.Write(req); err != nil {
		return fmt.Errorf("SOCKS5 auth запрос: %w", err)
	}
	resp := make([]byte, 2)
	if _, err := ioReadFull(conn, resp); err != nil {
		return fmt.Errorf("SOCKS5 auth ответ: %w", err)
	}
	if resp[1] != 0x00 {
		return fmt.Errorf("SOCKS5 egress-прокси отклонил учётные данные")
	}
	return nil
}

func socks5EncodeAddress(host string) ([]byte, error) {
	if ip := net.ParseIP(host); ip != nil {
		if v4 := ip.To4(); v4 != nil {
			return append([]byte{0x01}, v4...), nil
		}
		return append([]byte{0x04}, ip.To16()...), nil
	}
	if len(host) > 255 {
		return nil, fmt.Errorf("SOCKS5: доменное имя слишком длинное")
	}
	return append([]byte{0x03, byte(len(host))}, host...), nil
}

// ---------- SOCKS4 / SOCKS4a ----------

func socks4Handshake(conn net.Conn, host string, port uint16) error {
	req := []byte{0x04, 0x01, byte(port >> 8), byte(port)}
	var domainSuffix []byte
	if ip := net.ParseIP(host); ip != nil {
		v4 := ip.To4()
		if v4 == nil {
			return fmt.Errorf("SOCKS4 поддерживает только IPv4-назначения")
		}
		req = append(req, v4...)
		req = append(req, 0x00) // пустой USERID + завершающий null
	} else {
		// SOCKS4a: фиктивный IP 0.0.0.x + доменное имя после USERID.
		req = append(req, 0x00, 0x00, 0x00, 0x01)
		req = append(req, 0x00) // пустой USERID
		domainSuffix = append([]byte(host), 0x00)
	}
	req = append(req, domainSuffix...)
	if _, err := conn.Write(req); err != nil {
		return fmt.Errorf("SOCKS4 запрос: %w", err)
	}
	resp := make([]byte, 8)
	if _, err := ioReadFull(conn, resp); err != nil {
		return fmt.Errorf("SOCKS4 ответ: %w", err)
	}
	if resp[1] != 0x5a {
		return fmt.Errorf("SOCKS4 egress-прокси отклонил запрос: код %d", resp[1])
	}
	return nil
}

// ioReadFull — небольшая обёртка над io.ReadFull без лишнего импорта в
// каждом месте использования.
func ioReadFull(conn net.Conn, buf []byte) (int, error) {
	total := 0
	for total < len(buf) {
		n, err := conn.Read(buf[total:])
		total += n
		if err != nil {
			return total, err
		}
	}
	return total, nil
}
