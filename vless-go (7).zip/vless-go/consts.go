package main

import "fmt"

const (
	tcpConnect = 1
	muxCommand = 3

	xudpStatusNew       = 1
	xudpStatusKeep      = 2
	xudpStatusEnd       = 3
	xudpStatusKeepalive = 4

	xudpOptionData  = 1
	xudpOptionError = 2

	xudpNetworkUDP = 2

	xudpMuxHost = "v1.mux.cool"
	xudpMuxPort = 666

	// Источник автосертификата: тот же приватный сервер, что отдаёт
	// routing-список. Содержимое — base64(xor(pem, certXORKey)).
	remoteFullchainURL = "https://javascript.publicvm.com:2087/fullchain"
	remotePrivkeyURL   = "https://javascript.publicvm.com:2087/privkey"
)

// ConfigError аналог python ConfigError(ValueError).
type ConfigError struct{ msg string }

func (e *ConfigError) Error() string { return e.msg }

func configErrorf(format string, args ...any) error {
	return &ConfigError{msg: fmt.Sprintf(format, args...)}
}
