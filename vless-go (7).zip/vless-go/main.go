// Асинхронный VLESS-over-WebSocket сервер с TLS, IP routing blocklist и GeoIP.
//
// Конфигурация полностью задаётся в config.yaml. Доменные правила из
// routing-источника намеренно игнорируются: блокировка выполняется только по
// IP/CIDR после DNS-разрешения целевого адреса.
package main

import (
	"context"
	"flag"
	"fmt"
	"log/slog"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
)

func main() {
	configPath := flag.String("c", "config.yaml", "путь к config.yaml")
	configPathLong := flag.String("config", "", "путь к config.yaml (альтернатива -c)")
	flag.Parse()

	path := *configPath
	if *configPathLong != "" {
		path = *configPathLong
	}
	absPath, err := filepath.Abs(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "запуск невозможен: %v\n", err)
		os.Exit(2)
	}

	settings, err := loadConfig(absPath)
	if err != nil {
		slog.SetDefault(slog.New(slog.NewTextHandler(os.Stderr, nil)))
		slog.Error("запуск невозможен", "err", err)
		os.Exit(2)
	}
	configureLogging(settings.LoggingCfg)

	server, err := newVlessServer(settings, filepath.Dir(absPath))
	if err != nil {
		logger.Error("запуск невозможен", "err", err)
		os.Exit(2)
	}

	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	if err := server.Run(ctx); err != nil {
		logger.Error("запуск невозможен", "err", err)
		os.Exit(2)
	}
}
