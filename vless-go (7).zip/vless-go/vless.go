package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strings"
)

type vlessHandshake struct {
	Version  byte
	ClientID [16]byte
	Command  byte
	Host     string
	Port     uint16
	Offset   int
}

// parseVlessHandshake разбирает VLESS request, аналог python parse_vless_handshake.
func parseVlessHandshake(buf []byte) (*vlessHandshake, error) {
	pos := 0
	take := func(n int) ([]byte, error) {
		if n < 0 || pos+n > len(buf) {
			return nil, fmt.Errorf("неполный VLESS handshake")
		}
		chunk := buf[pos : pos+n]
		pos += n
		return chunk, nil
	}

	verB, err := take(1)
	if err != nil {
		return nil, err
	}
	version := verB[0]

	clientIDB, err := take(16)
	if err != nil {
		return nil, err
	}
	var clientID [16]byte
	copy(clientID[:], clientIDB)

	optLenB, err := take(1)
	if err != nil {
		return nil, err
	}
	optLen := int(optLenB[0])
	if _, err := take(optLen); err != nil {
		return nil, err
	}

	cmdB, err := take(1)
	if err != nil {
		return nil, err
	}
	command := cmdB[0]
	if command != tcpConnect && command != muxCommand {
		return nil, fmt.Errorf("поддерживаются TCP command=1 и XUDP/MUX command=3, получено %d", command)
	}

	if command == muxCommand {
		return &vlessHandshake{
			Version: version, ClientID: clientID, Command: command,
			Host: xudpMuxHost, Port: xudpMuxPort, Offset: pos,
		}, nil
	}

	portB, err := take(2)
	if err != nil {
		return nil, err
	}
	port := binary.BigEndian.Uint16(portB)

	addrTypeB, err := take(1)
	if err != nil {
		return nil, err
	}
	addrType := addrTypeB[0]

	var host string
	switch addrType {
	case 1:
		ipB, err := take(4)
		if err != nil {
			return nil, err
		}
		host = net.IP(ipB).To4().String()
	case 2:
		lenB, err := take(1)
		if err != nil {
			return nil, err
		}
		length := int(lenB[0])
		if length == 0 {
			return nil, fmt.Errorf("пустое доменное имя")
		}
		nameB, err := take(length)
		if err != nil {
			return nil, err
		}
		decoded, derr := idnaDecode(string(nameB))
		if derr != nil {
			return nil, derr
		}
		host = strings.TrimRight(decoded, ".")
	case 3:
		ipB, err := take(16)
		if err != nil {
			return nil, err
		}
		host = net.IP(ipB).To16().String()
	default:
		return nil, fmt.Errorf("неподдерживаемый тип адреса: %d", addrType)
	}

	return &vlessHandshake{
		Version: version, ClientID: clientID, Command: command,
		Host: host, Port: port, Offset: pos,
	}, nil
}
