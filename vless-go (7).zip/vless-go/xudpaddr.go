package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strings"
)

// parseXudpAddress аналог parse_xudp_address: (host, port, newPos).
func parseXudpAddress(data []byte, pos int) (string, uint16, int, error) {
	if pos+3 > len(data) {
		return "", 0, 0, fmt.Errorf("неполный XUDP-адрес")
	}
	port := binary.BigEndian.Uint16(data[pos:])
	pos += 2
	addrType := data[pos]
	pos++
	var host string
	switch addrType {
	case 1:
		if pos+4 > len(data) {
			return "", 0, 0, fmt.Errorf("неполный XUDP IPv4")
		}
		host = net.IP(data[pos : pos+4]).To4().String()
		pos += 4
	case 2:
		if pos >= len(data) {
			return "", 0, 0, fmt.Errorf("неполный XUDP domain")
		}
		length := int(data[pos])
		pos++
		if length == 0 || pos+length > len(data) {
			return "", 0, 0, fmt.Errorf("неверная длина XUDP domain")
		}
		decoded, err := idnaDecode(string(data[pos : pos+length]))
		if err != nil {
			return "", 0, 0, err
		}
		host = strings.TrimRight(decoded, ".")
		pos += length
	case 3:
		if pos+16 > len(data) {
			return "", 0, 0, fmt.Errorf("неполный XUDP IPv6")
		}
		host = net.IP(data[pos : pos+16]).To16().String()
		pos += 16
	default:
		return "", 0, 0, fmt.Errorf("неподдерживаемый тип XUDP-адреса: %d", addrType)
	}
	return host, port, pos, nil
}

// encodeXudpAddress аналог encode_xudp_address.
func encodeXudpAddress(host string, port uint16) ([]byte, error) {
	if ip := net.ParseIP(host); ip != nil {
		if v4 := ip.To4(); v4 != nil {
			out := make([]byte, 0, 7)
			out = binary.BigEndian.AppendUint16(out, port)
			out = append(out, 1)
			out = append(out, v4...)
			return out, nil
		}
		out := make([]byte, 0, 19)
		out = binary.BigEndian.AppendUint16(out, port)
		out = append(out, 3)
		out = append(out, ip.To16()...)
		return out, nil
	}
	encoded, err := idnaEncode(normalizeDomain(host))
	if err != nil {
		return nil, err
	}
	b := []byte(encoded)
	if len(b) == 0 || len(b) > 255 {
		return nil, fmt.Errorf("неверный XUDP domain")
	}
	out := make([]byte, 0, 4+len(b))
	out = binary.BigEndian.AppendUint16(out, port)
	out = append(out, 2, byte(len(b)))
	out = append(out, b...)
	return out, nil
}
