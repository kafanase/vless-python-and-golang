package main

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

// CloudflareRanges — список IPv4/IPv6-диапазонов Cloudflare (ASN 13335),
// используемый для egress_proxy.scope=cloudflare_only: решаем, направлять
// ли соединение через апстрим-прокси, по тому, попадает ли резолвленный IP
// назначения в один из этих диапазонов.
//
// Источник по умолчанию — официальные списки Cloudflare
// (https://www.cloudflare.com/ips-v4, /ips-v6): обычный текст, один
// CIDR на строку. Это проще и надёжнее, чем полноценный ASN/BGP-лукап, и
// не требует стороннего сервиса.
type CloudflareRanges struct {
	urlV4          string
	urlV6          string
	cacheFile      string
	refreshSeconds int
	timeout        time.Duration

	mu    sync.RWMutex
	nets  []*net.IPNet
	ready bool

	cancel context.CancelFunc
	done   chan struct{}
}

func newCloudflareRanges(cfg map[string]any, baseDir string) *CloudflareRanges {
	return &CloudflareRanges{
		urlV4:          toStr(cfg["cloudflare_ranges_url_v4"], "https://www.cloudflare.com/ips-v4"),
		urlV6:          toStr(cfg["cloudflare_ranges_url_v6"], "https://www.cloudflare.com/ips-v6"),
		cacheFile:      resolvePath(baseDir, toStr(cfg["cloudflare_cache_file"], "cloudflare-ips.cache")),
		refreshSeconds: toInt(cfg["cloudflare_refresh_seconds"], 86400),
		timeout:        time.Duration(toFloat(cfg["cloudflare_download_timeout"], 15) * float64(time.Second)),
	}
}

func (c *CloudflareRanges) Ready() bool {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.ready
}

// Contains сообщает, принадлежит ли IP одному из известных диапазонов
// Cloudflare.
func (c *CloudflareRanges) Contains(ip net.IP) bool {
	c.mu.RLock()
	defer c.mu.RUnlock()
	for _, n := range c.nets {
		if n.Contains(ip) {
			return true
		}
	}
	return false
}

func (c *CloudflareRanges) downloadOne(ctx context.Context, url string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(ctx, c.timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "vless-ws/2.1")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 4*1024*1024))
}

func parseCloudflareList(data []byte) ([]*net.IPNet, error) {
	lines := strings.Split(string(stripUTF8BOM(data)), "\n")
	var nets []*net.IPNet
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		n, err := parseIPNetworkLoose(line)
		if err != nil {
			continue // защитно пропускаем неожиданные строки, не валим весь список
		}
		nets = append(nets, n)
	}
	if len(nets) == 0 {
		return nil, errors.New("пустой список диапазонов")
	}
	return nets, nil
}

func (c *CloudflareRanges) refresh(ctx context.Context) error {
	v4data, errV4 := c.downloadOne(ctx, c.urlV4)
	v6data, errV6 := c.downloadOne(ctx, c.urlV6)
	if errV4 != nil && errV6 != nil {
		return fmt.Errorf("ips-v4: %v; ips-v6: %v", errV4, errV6)
	}

	var nets []*net.IPNet
	var cacheBuf bytes.Buffer
	if errV4 == nil {
		if n, perr := parseCloudflareList(v4data); perr == nil {
			nets = append(nets, n...)
			cacheBuf.Write(v4data)
			cacheBuf.WriteByte('\n')
		}
	}
	if errV6 == nil {
		if n, perr := parseCloudflareList(v6data); perr == nil {
			nets = append(nets, n...)
			cacheBuf.Write(v6data)
		}
	}
	if len(nets) == 0 {
		return fmt.Errorf("не удалось разобрать ни ips-v4, ни ips-v6 (v4 err=%v, v6 err=%v)", errV4, errV6)
	}

	c.mu.Lock()
	c.nets = nets
	c.ready = true
	c.mu.Unlock()

	if err := atomicWrite(c.cacheFile, cacheBuf.Bytes()); err != nil && logger != nil {
		logger.Warn("не удалось записать кэш Cloudflare ranges", "err", err)
	}
	if logger != nil {
		logger.Info("Cloudflare IP-диапазоны обновлены", "networks", len(nets))
	}
	return nil
}

// Start выполняет обязательное первое получение списков (с фолбэком на
// дисковый кэш при неудаче) и запускает фоновое периодическое обновление.
func (c *CloudflareRanges) Start(ctx context.Context) error {
	if err := c.refresh(ctx); err != nil {
		if logger != nil {
			logger.Warn("не удалось скачать Cloudflare IP-диапазоны, пробуем кэш", "err", err)
		}
		data, rerr := os.ReadFile(c.cacheFile)
		if rerr != nil {
			return fmt.Errorf("Cloudflare IP-диапазоны недоступны и кэш отсутствует (скачивание: %v; кэш: %v)", err, rerr)
		}
		nets, perr := parseCloudflareList(data)
		if perr != nil {
			return fmt.Errorf("повреждён кэш Cloudflare IP-диапазонов %s: %w", c.cacheFile, perr)
		}
		c.mu.Lock()
		c.nets = nets
		c.ready = true
		c.mu.Unlock()
		if logger != nil {
			logger.Info("использован кэш Cloudflare IP-диапазонов", "file", c.cacheFile, "networks", len(nets))
		}
	}
	if c.refreshSeconds > 0 {
		runCtx, cancel := context.WithCancel(ctx)
		c.cancel = cancel
		c.done = make(chan struct{})
		go c.run(runCtx)
	}
	return nil
}

func (c *CloudflareRanges) run(ctx context.Context) {
	defer close(c.done)
	interval := time.Duration(c.refreshSeconds) * time.Second
	if interval < time.Hour {
		interval = time.Hour
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			if err := c.refresh(ctx); err != nil && logger != nil {
				logger.Warn("не удалось обновить Cloudflare IP-диапазоны, используются предыдущие", "err", err)
			}
		}
	}
}

func (c *CloudflareRanges) Stop() {
	if c.cancel != nil {
		c.cancel()
		<-c.done
	}
}
