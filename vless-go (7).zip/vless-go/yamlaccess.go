package main

import "fmt"

func asMap(v any) map[string]any {
	if v == nil {
		return map[string]any{}
	}
	if m, ok := v.(map[string]any); ok {
		return m
	}
	return map[string]any{}
}

func mapGet(m map[string]any, key string) any {
	if m == nil {
		return nil
	}
	return m[key]
}

func toStr(v any, def string) string {
	if v == nil {
		return def
	}
	switch t := v.(type) {
	case string:
		return t
	case bool:
		if t {
			return "true"
		}
		return "false"
	case int64:
		return fmt.Sprintf("%d", t)
	case float64:
		return fmt.Sprintf("%v", t)
	default:
		return fmt.Sprintf("%v", t)
	}
}

func toBool(v any, def bool) bool {
	if v == nil {
		return def
	}
	if b, ok := v.(bool); ok {
		return b
	}
	if s, ok := v.(string); ok {
		switch s {
		case "true", "yes", "on", "1":
			return true
		case "false", "no", "off", "0":
			return false
		}
	}
	return def
}

func toInt(v any, def int) int {
	if v == nil {
		return def
	}
	switch t := v.(type) {
	case int64:
		return int(t)
	case float64:
		return int(t)
	}
	return def
}

func toFloat(v any, def float64) float64 {
	if v == nil {
		return def
	}
	switch t := v.(type) {
	case int64:
		return float64(t)
	case float64:
		return t
	}
	return def
}

func toList(v any) []any {
	if v == nil {
		return nil
	}
	if l, ok := v.([]any); ok {
		return l
	}
	// одиночная строка тоже допустима как список из одного элемента
	return []any{v}
}

func toStrList(v any) []string {
	l := toList(v)
	out := make([]string, 0, len(l))
	for _, item := range l {
		out = append(out, toStr(item, ""))
	}
	return out
}
