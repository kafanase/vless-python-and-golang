package main

// yamllite — минимальный парсер подмножества YAML, достаточного для config.yaml
// этого сервера: вложенные блочные отображения (map), блочные и flow-списки,
// скалярные значения (строки/числа/bool/null), комментарии "#", кавычки.
// Полноценный YAML (anchors, multiline blocks и т.д.) не поддерживается —
// он и не требуется для формата конфигурации этого проекта.

import (
	"fmt"
	"strconv"
	"strings"
)

func yamlParse(input string) (map[string]any, error) {
	lines := splitYAMLLines(input)
	root := map[string]any{}
	_, err := yamlParseBlock(lines, 0, 0, root)
	if err != nil {
		return nil, err
	}
	return root, nil
}

type yamlLine struct {
	indent int
	text   string // содержимое строки после отступа, без завершающих пробелов
}

func splitYAMLLines(input string) []yamlLine {
	raw := strings.Split(strings.ReplaceAll(input, "\r\n", "\n"), "\n")
	var out []yamlLine
	for _, l := range raw {
		stripped := stripYAMLComment(l)
		trimmedRight := strings.TrimRight(stripped, " \t")
		if strings.TrimSpace(trimmedRight) == "" {
			continue
		}
		indent := 0
		for indent < len(trimmedRight) && trimmedRight[indent] == ' ' {
			indent++
		}
		out = append(out, yamlLine{indent: indent, text: trimmedRight[indent:]})
	}
	return out
}

// stripYAMLComment удаляет "# ..." вне кавычек.
func stripYAMLComment(l string) string {
	inSingle, inDouble := false, false
	for i := 0; i < len(l); i++ {
		c := l[i]
		switch {
		case c == '\'' && !inDouble:
			inSingle = !inSingle
		case c == '"' && !inSingle:
			inDouble = !inDouble
		case c == '#' && !inSingle && !inDouble:
			if i == 0 || l[i-1] == ' ' || l[i-1] == '\t' {
				return l[:i]
			}
		}
	}
	return l
}

// yamlParseBlock разбирает последовательность строк с отступом >= minIndent,
// начиная с индекса start, заполняя map dst. Возвращает индекс следующей
// необработанной строки.
func yamlParseBlock(lines []yamlLine, start int, minIndent int, dst map[string]any) (int, error) {
	if start >= len(lines) {
		return start, nil
	}
	blockIndent := lines[start].indent
	if blockIndent < minIndent {
		return start, nil
	}
	i := start
	for i < len(lines) {
		line := lines[i]
		if line.indent != blockIndent {
			if line.indent < blockIndent {
				break
			}
			return i, fmt.Errorf("yaml: неожиданный отступ на строке %q", line.text)
		}
		if strings.HasPrefix(line.text, "- ") || line.text == "-" {
			return i, fmt.Errorf("yaml: список там, где ожидалось отображение: %q", line.text)
		}
		key, rest, err := splitYAMLKey(line.text)
		if err != nil {
			return i, err
		}
		if rest == "" {
			// Значение — вложенный блок на следующих строках (map или список),
			// либо null, если далее ничего с большим отступом нет.
			if i+1 < len(lines) && lines[i+1].indent > blockIndent {
				if strings.HasPrefix(lines[i+1].text, "- ") || lines[i+1].text == "-" {
					list, next, err := yamlParseList(lines, i+1, lines[i+1].indent)
					if err != nil {
						return i, err
					}
					dst[key] = list
					i = next
					continue
				}
				sub := map[string]any{}
				next, err := yamlParseBlock(lines, i+1, lines[i+1].indent, sub)
				if err != nil {
					return i, err
				}
				dst[key] = sub
				i = next
				continue
			}
			dst[key] = nil
			i++
			continue
		}
		dst[key] = yamlParseScalar(rest)
		i++
	}
	return i, nil
}

func yamlParseList(lines []yamlLine, start int, indent int) ([]any, int, error) {
	var out []any
	i := start
	for i < len(lines) {
		line := lines[i]
		if line.indent != indent {
			if line.indent < indent {
				break
			}
			return out, i, fmt.Errorf("yaml: неожиданный отступ в списке: %q", line.text)
		}
		if !(strings.HasPrefix(line.text, "- ") || line.text == "-") {
			break
		}
		item := strings.TrimPrefix(line.text, "-")
		item = strings.TrimPrefix(item, " ")
		if item == "" {
			// вложенный map/список под "-" на следующей строке
			if i+1 < len(lines) && lines[i+1].indent > indent {
				sub := map[string]any{}
				next, err := yamlParseBlock(lines, i+1, lines[i+1].indent, sub)
				if err != nil {
					return out, i, err
				}
				out = append(out, sub)
				i = next
				continue
			}
			out = append(out, nil)
			i++
			continue
		}
		if key, rest, err := splitYAMLKey(item); err == nil && looksLikeMapItem(item) {
			sub := map[string]any{}
			sub[key] = yamlParseScalar(rest)
			// возможные дополнительные ключи того же отображения с тем же
			// отступом что и "- " плюс 2 пробела не поддерживаются — для
			// схемы этого config.yaml не требуется.
			out = append(out, sub)
			i++
			continue
		}
		out = append(out, yamlParseScalar(item))
		i++
	}
	return out, i, nil
}

func looksLikeMapItem(s string) bool {
	c := stripYAMLComment(s)
	idx := strings.Index(c, ":")
	if idx <= 0 {
		return false
	}
	after := c[idx+1:]
	return after == "" || strings.HasPrefix(after, " ")
}

func splitYAMLKey(s string) (key string, rest string, err error) {
	idx := strings.Index(s, ":")
	if idx < 0 {
		return "", "", fmt.Errorf("yaml: ожидался 'key: value', получено %q", s)
	}
	key = strings.TrimSpace(unquoteYAML(s[:idx]))
	rest = strings.TrimSpace(s[idx+1:])
	return key, rest, nil
}

func unquoteYAML(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 {
		if (s[0] == '"' && s[len(s)-1] == '"') || (s[0] == '\'' && s[len(s)-1] == '\'') {
			return s[1 : len(s)-1]
		}
	}
	return s
}

// yamlParseScalar разбирает строковое значение YAML: null, bool, число,
// flow-список "[a, b]", flow-map "{a: b}" или строку (с кавычками либо без).
func yamlParseScalar(s string) any {
	s = strings.TrimSpace(s)
	if s == "" || s == "~" || s == "null" || s == "Null" || s == "NULL" {
		return nil
	}
	if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
		inner := strings.TrimSpace(s[1 : len(s)-1])
		if inner == "" {
			return []any{}
		}
		parts := splitYAMLFlow(inner)
		out := make([]any, 0, len(parts))
		for _, p := range parts {
			out = append(out, yamlParseScalar(strings.TrimSpace(p)))
		}
		return out
	}
	if strings.HasPrefix(s, "{") && strings.HasSuffix(s, "}") {
		inner := strings.TrimSpace(s[1 : len(s)-1])
		m := map[string]any{}
		if inner != "" {
			for _, p := range splitYAMLFlow(inner) {
				k, v, err := splitYAMLKey(strings.TrimSpace(p))
				if err == nil {
					m[k] = yamlParseScalar(v)
				}
			}
		}
		return m
	}
	if len(s) >= 2 && ((s[0] == '"' && s[len(s)-1] == '"') || (s[0] == '\'' && s[len(s)-1] == '\'')) {
		return unquoteYAML(s)
	}
	switch strings.ToLower(s) {
	case "true", "yes", "on":
		return true
	case "false", "no", "off":
		return false
	}
	if iv, err := strconv.ParseInt(s, 10, 64); err == nil {
		return iv
	}
	if fv, err := strconv.ParseFloat(s, 64); err == nil {
		return fv
	}
	return s
}

// splitYAMLFlow делит "a, b, [c, d], e" по верхнеуровневым запятым.
func splitYAMLFlow(s string) []string {
	var out []string
	depth := 0
	inSingle, inDouble := false, false
	last := 0
	for i, c := range s {
		switch {
		case c == '\'' && !inDouble:
			inSingle = !inSingle
		case c == '"' && !inSingle:
			inDouble = !inDouble
		case (c == '[' || c == '{') && !inSingle && !inDouble:
			depth++
		case (c == ']' || c == '}') && !inSingle && !inDouble:
			depth--
		case c == ',' && depth == 0 && !inSingle && !inDouble:
			out = append(out, s[last:i])
			last = i + 1
		}
	}
	out = append(out, s[last:])
	return out
}
