package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type countryIndex struct {
	starts4 []*big.Int
	nets4   []*net.IPNet
	starts6 []*big.Int
	nets6   []*net.IPNet
}

type GeoFilter struct {
	enabled      bool
	mode         string // "allow" | "deny"
	countries    map[string]bool
	unknown      string // "allow" | "deny"
	autoDownload bool
	failClosed   bool
	timeout      time.Duration
	cacheDir     string
	urlTemplate  string

	indexes map[string]countryIndex
}

func newGeoFilter(cfg map[string]any, baseDir string) (*GeoFilter, error) {
	enabled := toBool(cfg["enabled"], false)
	mode := strings.ToLower(toStr(cfg["mode"], "deny"))
	if mode != "allow" && mode != "deny" {
		return nil, configErrorf("geofilter.mode должен быть allow или deny")
	}
	countries := map[string]bool{}
	for _, c := range toStrList(cfg["countries"]) {
		countries[strings.ToUpper(c)] = true
	}
	defaultUnknown := "allow"
	if mode == "allow" {
		defaultUnknown = "deny"
	}
	unknown := strings.ToLower(toStr(cfg["unknown"], defaultUnknown))
	if unknown != "allow" && unknown != "deny" {
		return nil, configErrorf("geofilter.unknown должен быть allow или deny")
	}
	urlTemplate := toStr(cfg["source_url_template"],
		"https://raw.githubusercontent.com/ipverse/geo-ip-blocks/refs/heads/master/country/{country}/{country}.json")

	return &GeoFilter{
		enabled:      enabled,
		mode:         mode,
		countries:    countries,
		unknown:      unknown,
		autoDownload: toBool(cfg["auto_download"], true),
		failClosed:   toBool(cfg["fail_closed"], true),
		timeout:      time.Duration(toFloat(cfg["download_timeout"], 30) * float64(time.Second)),
		cacheDir:     resolvePath(baseDir, toStr(cfg["cache_dir"], "geoip-cache")),
		urlTemplate:  urlTemplate,
		indexes:      map[string]countryIndex{},
	}, nil
}

func (g *GeoFilter) downloadCountry(ctx context.Context, country string) ([]byte, error) {
	lower := strings.ToLower(country)
	url := strings.ReplaceAll(g.urlTemplate, "{country}", lower)
	url = strings.ReplaceAll(url, "{COUNTRY}", country)
	ctx, cancel := context.WithTimeout(ctx, g.timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "vless-ws/2.1")
	req.Header.Set("Accept", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 64*1024*1024))
}

type ipverseDoc struct {
	CountryCode string `json:"countryCode"`
	Prefixes    struct {
		IPv4 []string `json:"ipv4"`
		IPv6 []string `json:"ipv6"`
	} `json:"prefixes"`
}

func parseCountryJSON(data []byte, expected string) ([]*net.IPNet, []*net.IPNet, error) {
	var doc ipverseDoc
	if err := json.Unmarshal(stripUTF8BOM(data), &doc); err != nil {
		return nil, nil, fmt.Errorf("неверный формат ipverse JSON: %w", err)
	}
	actual := strings.ToUpper(doc.CountryCode)
	if actual != "" && actual != expected {
		return nil, nil, fmt.Errorf("ожидалась страна %s, получена %s", expected, actual)
	}
	var v4, v6 []*net.IPNet
	for _, item := range doc.Prefixes.IPv4 {
		n, err := parseIPNetworkLoose(item)
		if err != nil {
			return nil, nil, fmt.Errorf("неверный CIDR в списке %s: %v", expected, err)
		}
		if netVersion(n) != 4 {
			return nil, nil, fmt.Errorf("перепутано семейство IP в списке %s", expected)
		}
		v4 = append(v4, n)
	}
	for _, item := range doc.Prefixes.IPv6 {
		n, err := parseIPNetworkLoose(item)
		if err != nil {
			return nil, nil, fmt.Errorf("неверный CIDR в списке %s: %v", expected, err)
		}
		if netVersion(n) != 6 {
			return nil, nil, fmt.Errorf("перепутано семейство IP в списке %s", expected)
		}
		v6 = append(v6, n)
	}
	if len(v4) == 0 && len(v6) == 0 {
		return nil, nil, fmt.Errorf("пустой список префиксов %s", expected)
	}
	return collapseNets(v4), collapseNets(v6), nil
}

// collapseNets — упрощённый аналог ipaddress.collapse_addresses: просто
// сортирует сети (полноценное объединение перекрывающихся диапазонов не
// требуется для корректности проверки принадлежности, только для экономии
// памяти).
func collapseNets(nets []*net.IPNet) []*net.IPNet {
	sort.Slice(nets, func(i, j int) bool {
		ci := new(big.Int).SetBytes(nets[i].IP)
		cj := new(big.Int).SetBytes(nets[j].IP)
		if cmp := ci.Cmp(cj); cmp != 0 {
			return cmp < 0
		}
		pi, _ := nets[i].Mask.Size()
		pj, _ := nets[j].Mask.Size()
		return pi < pj
	})
	return nets
}

func (g *GeoFilter) loadCountry(ctx context.Context, country string) ([]*net.IPNet, []*net.IPNet, error) {
	cacheFile := filepath.Join(g.cacheDir, strings.ToLower(country)+".json")
	var downloadErr error
	if g.autoDownload {
		data, err := g.downloadCountry(ctx, country)
		if err == nil {
			v4, v6, perr := parseCountryJSON(data, country)
			if perr == nil {
				_ = atomicWrite(cacheFile, data)
				return v4, v6, nil
			}
			downloadErr = perr
		} else {
			downloadErr = err
		}
		if logger != nil {
			logger.Warn("GeoIP загрузка не удалась", "country", country, "err", downloadErr)
		}
	}
	if data, err := os.ReadFile(cacheFile); err == nil {
		v4, v6, perr := parseCountryJSON(data, country)
		if perr != nil {
			return nil, nil, configErrorf("повреждён GeoIP-кэш %s: %v", cacheFile, perr)
		}
		return v4, v6, nil
	}
	if downloadErr != nil {
		return nil, nil, configErrorf("GeoIP %s недоступен и кэш отсутствует: %v", country, downloadErr)
	}
	return nil, nil, configErrorf("GeoIP-кэш не найден: %s", cacheFile)
}

func (g *GeoFilter) Open(ctx context.Context) error {
	if !g.enabled {
		return nil
	}
	if len(g.countries) == 0 {
		return configErrorf("geofilter.countries пуст")
	}
	if err := os.MkdirAll(g.cacheDir, 0o755); err != nil {
		return err
	}
	var countries []string
	for c := range g.countries {
		countries = append(countries, c)
	}
	sort.Strings(countries)

	var failures []string
	for _, country := range countries {
		v4, v6, err := g.loadCountry(ctx, country)
		if err != nil {
			failures = append(failures, fmt.Sprintf("%s: %v", country, err))
			if logger != nil {
				logger.Error("GeoIP", "err", failures[len(failures)-1])
			}
			continue
		}
		idx := countryIndex{nets4: v4, nets6: v6}
		for _, n := range v4 {
			idx.starts4 = append(idx.starts4, new(big.Int).SetBytes(n.IP))
		}
		for _, n := range v6 {
			idx.starts6 = append(idx.starts6, new(big.Int).SetBytes(n.IP))
		}
		g.indexes[country] = idx
		if logger != nil {
			logger.Info("GeoIP загружено", "country", country, "ipv4", len(v4), "ipv6", len(v6))
		}
	}
	if len(failures) > 0 && g.failClosed {
		return configErrorf("не удалось загрузить GeoIP: %s", strings.Join(failures, "; "))
	}
	if len(g.indexes) == 0 && logger != nil {
		logger.Warn("GeoIP работает fail-open: списки стран недоступны")
	}
	return nil
}

func broadcastAddress(n *net.IPNet) *big.Int {
	ones, bits := n.Mask.Size()
	base := new(big.Int).SetBytes(n.IP)
	hostBits := bits - ones
	if hostBits <= 0 {
		return base
	}
	mask := new(big.Int).Lsh(big.NewInt(1), uint(hostBits))
	mask.Sub(mask, big.NewInt(1))
	return new(big.Int).Or(base, mask)
}

func indexContains(value *big.Int, starts []*big.Int, nets []*net.IPNet) bool {
	// bisect_right(starts, value) - 1
	idx := sort.Search(len(starts), func(i int) bool { return starts[i].Cmp(value) > 0 }) - 1
	if idx < 0 {
		return false
	}
	return value.Cmp(broadcastAddress(nets[idx])) <= 0
}

// Allowed аналог GeoFilter.allowed: возвращает (allowed, matchedCountry).
func (g *GeoFilter) Allowed(address string) (bool, string) {
	if !g.enabled {
		return true, ""
	}
	ip := net.ParseIP(address)
	if ip == nil {
		return g.unknown == "allow", ""
	}
	if ip.IsLoopback() || isPrivateIP(ip) {
		return true, ""
	}
	value := new(big.Int).SetBytes(normalizeIPBytes(ip))
	isV4 := ip.To4() != nil
	var matched string
	for country, idx := range g.indexes {
		var ok bool
		if isV4 {
			ok = indexContains(value, idx.starts4, idx.nets4)
		} else {
			ok = indexContains(value, idx.starts6, idx.nets6)
		}
		if ok {
			matched = country
			break
		}
	}
	if g.mode == "deny" {
		return matched == "", matched
	}
	if matched != "" {
		return true, matched
	}
	return g.unknown == "allow", ""
}

func (g *GeoFilter) Close() {
	g.indexes = map[string]countryIndex{}
}

func normalizeIPBytes(ip net.IP) []byte {
	if v4 := ip.To4(); v4 != nil {
		return v4
	}
	return ip.To16()
}

func isPrivateIP(ip net.IP) bool {
	privateBlocks := []string{
		"10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8",
		"169.254.0.0/16", "fc00::/7", "fe80::/10", "::1/128",
	}
	for _, b := range privateBlocks {
		_, n, err := net.ParseCIDR(b)
		if err == nil && n.Contains(ip) {
			return true
		}
	}
	return false
}
