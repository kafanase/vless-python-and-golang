package main

import (
	"bytes"
	"strings"
)

// AbuseFilter — эвристический анти-абуз фильтр: блокирует BitTorrent-трафик
// по портам и по сигнатуре handshake, а также попытки "прокси в прокси"
// (клиент открывает через наш VLESS-туннель ещё один SOCKS4/5 или
// HTTP(S)-прокси). Работает по двум независимым сигналам:
//
//  1. Порт назначения (быстрая проверка до подключения).
//  2. Сигнатура первых байт полезной нагрузки (после подключения/до
//     первой пересылки данных клиента).
//
// ОГРАНИЧЕНИЕ: если клиент устанавливает TLS к самому SOCKS/HTTP-прокси
// (т.е. "SOCKS/HTTP поверх TLS"), содержимое handshake'а прокси-протокола
// зашифровано внутри TLS ClientHello/ApplicationData и недоступно для
// сигнатурного анализа без MITM — такие случаи ловятся только по порту.
type AbuseFilter struct {
	enabled            bool
	blockTorrent       bool
	blockProxyChaining bool
	blockedPorts       map[uint16]bool
}

// Порты, по умолчанию ассоциируемые с BitTorrent (peer wire protocol, DHT,
// UDP-трекеры, дефолтные порты популярных клиентов).
var defaultTorrentPorts = []uint16{
	6881, 6882, 6883, 6884, 6885, 6886, 6887, 6888, 6889,
	6969,  // UDP tracker / часто и TCP tracker
	51413, // Transmission по умолчанию
	6970,
}

// Порты, по умолчанию ассоциируемые с проксированием (SOCKS/HTTP(S)).
var defaultProxyPorts = []uint16{
	1080, 1081, // SOCKS
	3128,       // Squid
	8080, 8118, // общий HTTP-прокси, Privoxy
	8888,
	9050, 9150, // Tor SOCKS
}

func newAbuseFilter(cfg map[string]any) *AbuseFilter {
	enabled := toBool(cfg["enabled"], true)
	blockTorrent := toBool(cfg["block_torrent"], true)
	blockProxy := toBool(cfg["block_proxy_chaining"], true)

	ports := map[uint16]bool{}
	if blockTorrent {
		for _, p := range defaultTorrentPorts {
			ports[p] = true
		}
	}
	if blockProxy {
		for _, p := range defaultProxyPorts {
			ports[p] = true
		}
	}
	for _, v := range toList(cfg["extra_blocked_ports"]) {
		if p := toInt(v, 0); p > 0 && p <= 65535 {
			ports[uint16(p)] = true
		}
	}

	return &AbuseFilter{
		enabled:            enabled,
		blockTorrent:       blockTorrent,
		blockProxyChaining: blockProxy,
		blockedPorts:       ports,
	}
}

// BlockedPort — быстрая проверка по номеру порта назначения.
func (f *AbuseFilter) BlockedPort(port uint16) bool {
	if !f.enabled {
		return false
	}
	return f.blockedPorts[port]
}

// SniffPayload анализирует первые байты полезной нагрузки, отправляемой
// клиентом на destination, и возвращает (заблокировано, причина).
func (f *AbuseFilter) SniffPayload(payload []byte) (bool, string) {
	if !f.enabled || len(payload) == 0 {
		return false, ""
	}
	if f.blockTorrent && looksLikeBitTorrentHandshake(payload) {
		return true, "BitTorrent peer handshake"
	}
	if f.blockProxyChaining {
		if looksLikeSocks5ClientGreeting(payload) {
			return true, "SOCKS5 handshake"
		}
		if looksLikeSocks4Request(payload) {
			return true, "SOCKS4/4a handshake"
		}
		if looksLikeHTTPProxyRequest(payload) {
			return true, "HTTP(S)-прокси CONNECT/absolute-URI"
		}
	}
	return false, ""
}

// looksLikeBitTorrentHandshake — стандартный BitTorrent peer wire protocol
// handshake: 0x13 ("pstrlen"=19) + ASCII "BitTorrent protocol" (19 байт).
func looksLikeBitTorrentHandshake(p []byte) bool {
	const magic = "BitTorrent protocol"
	if len(p) < 1+len(magic) {
		return false
	}
	if p[0] != 19 {
		return false
	}
	return string(p[1:1+len(magic)]) == magic
}

// looksLikeSocks5ClientGreeting — SOCKS5: VER=0x05, NMETHODS, затем ровно
// NMETHODS байт методов аутентификации.
func looksLikeSocks5ClientGreeting(p []byte) bool {
	if len(p) < 3 || p[0] != 0x05 {
		return false
	}
	n := int(p[1])
	if n == 0 {
		return false
	}
	return len(p) == 2+n
}

// looksLikeSocks4Request — SOCKS4/4a: VER=0x04, CMD in {1,2}, DSTPORT(2),
// DSTIP(4), USERID..\x00[, DOMAIN..\x00 для 4a].
func looksLikeSocks4Request(p []byte) bool {
	if len(p) < 9 || p[0] != 0x04 {
		return false
	}
	if p[1] != 0x01 && p[1] != 0x02 {
		return false
	}
	// USERID должен заканчиваться нулевым байтом где-то после DSTPORT+DSTIP.
	return bytes.IndexByte(p[8:], 0x00) >= 0
}

// looksLikeHTTPProxyRequest распознаёт запрос форвардинг-HTTP(S)-прокси:
// либо метод CONNECT (туннелирование HTTPS), либо GET/POST/HEAD с
// абсолютным URI в строке запроса (характерно именно для прокси, у
// origin-серверов request-target — путь, а не полный URL).
func looksLikeHTTPProxyRequest(p []byte) bool {
	head := p
	if len(head) > 512 {
		head = head[:512]
	}
	upper := strings.ToUpper(string(head))
	if strings.HasPrefix(upper, "CONNECT ") && strings.Contains(upper, " HTTP/1.") {
		return true
	}
	for _, method := range []string{"GET ", "POST ", "HEAD ", "PUT ", "DELETE ", "OPTIONS "} {
		if strings.HasPrefix(upper, method) {
			rest := upper[len(method):]
			if strings.HasPrefix(rest, "HTTP://") || strings.HasPrefix(rest, "HTTPS://") {
				return true
			}
		}
	}
	return false
}
