package main

import (
	"context"
	"errors"
	"fmt"
	"net"
	"sync"
	"time"
)

type resolvedCandidate struct {
	family int // 4 или 6
	ip     net.IP
}

func resolveTarget(ctx context.Context, host string, port uint16) ([]resolvedCandidate, error) {
	if ip := net.ParseIP(host); ip != nil {
		if v4 := ip.To4(); v4 != nil {
			return []resolvedCandidate{{family: 4, ip: v4}}, nil
		}
		return []resolvedCandidate{{family: 6, ip: ip.To16()}}, nil
	}
	addrs, err := net.DefaultResolver.LookupIPAddr(ctx, host)
	if err != nil {
		return nil, err
	}
	seen := map[string]bool{}
	var out []resolvedCandidate
	for _, a := range addrs {
		family := 6
		ip := a.IP.To16()
		if v4 := a.IP.To4(); v4 != nil {
			family = 4
			ip = v4
		}
		key := ip.String()
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, resolvedCandidate{family: family, ip: ip})
	}
	if len(out) == 0 {
		return nil, errors.New("адрес не разрешён")
	}
	return out, nil
}

type sendFrameFunc func(sessionID uint16, payload []byte, srcIP net.IP, srcPort int) error

type XUDPSession struct {
	sessionID uint16
	server    *VlessServer
	sendFrame sendFrameFunc

	mu          sync.Mutex
	hasDefault  bool
	defaultHost string
	defaultPort uint16

	conns  map[int]*net.UDPConn
	wg     sync.WaitGroup
	closed bool
	cancel context.CancelFunc

	socksMu    sync.Mutex
	socksAssoc *socks5UDPAssociation
}

func newXUDPSession(sessionID uint16, server *VlessServer, sendFrame sendFrameFunc) *XUDPSession {
	return &XUDPSession{
		sessionID: sessionID,
		server:    server,
		sendFrame: sendFrame,
		conns:     map[int]*net.UDPConn{},
	}
}

func (s *XUDPSession) socketFor(ctx context.Context, family int) (*net.UDPConn, error) {
	s.mu.Lock()
	if conn, ok := s.conns[family]; ok {
		s.mu.Unlock()
		return conn, nil
	}
	network := "udp4"
	laddr := &net.UDPAddr{IP: net.IPv4zero, Port: 0}
	if family == 6 {
		network = "udp6"
		laddr = &net.UDPAddr{IP: net.IPv6zero, Port: 0}
	}
	conn, err := net.ListenUDP(network, laddr)
	if err != nil {
		s.mu.Unlock()
		return nil, err
	}
	s.conns[family] = conn
	if s.cancel == nil {
		var loopCtx context.Context
		loopCtx, s.cancel = context.WithCancel(context.Background())
		_ = loopCtx
	}
	s.mu.Unlock()

	s.wg.Add(1)
	go s.receiveLoop(conn)
	return conn, nil
}

func (s *XUDPSession) receiveLoop(conn *net.UDPConn) {
	defer s.wg.Done()
	buf := make([]byte, 65535)
	for {
		n, addr, err := conn.ReadFromUDP(buf)
		if err != nil {
			return
		}
		if n == 0 {
			continue
		}
		payload := make([]byte, n)
		copy(payload, buf[:n])
		if err := s.sendFrame(s.sessionID, payload, addr.IP, addr.Port); err != nil {
			return
		}
	}
}

// Send аналог XUDPSession.send. destHost != "" означает явное назначение
// (XUDP NEW), иначе используется ранее сохранённое.
func (s *XUDPSession) Send(ctx context.Context, payload []byte, destHost string, destPort uint16, hasDest bool) error {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return nil
	}
	if hasDest {
		s.defaultHost, s.defaultPort, s.hasDefault = destHost, destPort, true
	} else if !s.hasDefault {
		s.mu.Unlock()
		return errors.New("XUDP KEEP без адреса до NEW")
	}
	host, port := s.defaultHost, s.defaultPort
	s.mu.Unlock()

	if s.server.routing.BlockedHost(host) {
		return &permissionError{msg: "XUDP назначение заблокировано routing-правилом: " + host}
	}
	if s.server.abuse.BlockedPort(port) {
		return &permissionError{msg: fmt.Sprintf("XUDP порт назначения заблокирован анти-абуз фильтром: %d", port)}
	}

	egress := s.server.egress

	if egress != nil && egress.Enabled && egress.Scope == "all" {
		// DNS назначения резолвит сам SOCKS5-прокси (UDP ASSOCIATE) — для
		// scope=all локальный резолвинг/IP-blocklist не нужен, как и в TCP.
		if egress.Protocol != "socks5" {
			s.server.udpEgressWarnOnce.Do(func() {
				if logger != nil {
					logger.Warn("egress_proxy.scope=all с protocol!=" + egress.Protocol +
						", но UDP/XUDP можно проксировать только через socks5 (UDP ASSOCIATE) — используется прямой выход")
				}
			})
			return s.sendDirect(ctx, payload, host, port)
		}
		return s.sendViaSocks5(ctx, payload, host, port)
	}

	// egress выключен либо scope=cloudflare_only — в обоих случаях нужен
	// реальный IP назначения: для локального IP-based routing blocklist и
	// для сверки с диапазонами Cloudflare.
	connectCtx, cancel := context.WithTimeout(ctx, time.Duration(s.server.cfg.ConnectTimeoutSec*float64(time.Second)))
	candidates, err := resolveTarget(connectCtx, host, port)
	cancel()
	if err != nil {
		return err
	}
	var filtered []resolvedCandidate
	for _, c := range candidates {
		if !s.server.routing.BlockedIP(c.ip) {
			filtered = append(filtered, c)
		}
	}
	if len(filtered) == 0 {
		return &permissionError{msg: "XUDP адрес назначения заблокирован: " + host}
	}
	chosen := filtered[0]

	if egress != nil && egress.Enabled && egress.Scope == "cloudflare_only" &&
		s.server.cfRanges != nil && s.server.cfRanges.Contains(chosen.ip) {
		if egress.Protocol != "socks5" {
			s.server.udpEgressWarnOnce.Do(func() {
				if logger != nil {
					logger.Warn("Cloudflare-адрес по UDP, но egress_proxy.protocol!=" + egress.Protocol +
						" — UDP ASSOCIATE поддерживает только socks5, используется прямой выход")
				}
			})
		} else {
			return s.sendViaSocks5(ctx, payload, chosen.ip.String(), port)
		}
	}

	return s.sendDirectToCandidate(ctx, chosen, payload, port)
}

// sendDirect резолвит host локально и шлёт напрямую (используется как
// фолбэк, когда egress включён, но протокол не поддерживает UDP).
func (s *XUDPSession) sendDirect(ctx context.Context, payload []byte, host string, port uint16) error {
	connectCtx, cancel := context.WithTimeout(ctx, time.Duration(s.server.cfg.ConnectTimeoutSec*float64(time.Second)))
	candidates, err := resolveTarget(connectCtx, host, port)
	cancel()
	if err != nil {
		return err
	}
	var filtered []resolvedCandidate
	for _, c := range candidates {
		if !s.server.routing.BlockedIP(c.ip) {
			filtered = append(filtered, c)
		}
	}
	if len(filtered) == 0 {
		return &permissionError{msg: "XUDP адрес назначения заблокирован: " + host}
	}
	return s.sendDirectToCandidate(ctx, filtered[0], payload, port)
}

func (s *XUDPSession) sendDirectToCandidate(ctx context.Context, chosen resolvedCandidate, payload []byte, port uint16) error {
	conn, err := s.socketFor(ctx, chosen.family)
	if err != nil {
		return err
	}
	_, err = conn.WriteToUDP(payload, &net.UDPAddr{IP: chosen.ip, Port: int(port)})
	return err
}

// getOrCreateSocksAssoc лениво поднимает SOCKS5 UDP ASSOCIATE-ассоциацию
// для этой XUDP-сессии (одна ассоциация на сессию, переиспользуется для
// всех датаграмм независимо от адреса назначения).
func (s *XUDPSession) getOrCreateSocksAssoc(ctx context.Context) (*socks5UDPAssociation, error) {
	s.socksMu.Lock()
	defer s.socksMu.Unlock()
	if s.socksAssoc != nil {
		return s.socksAssoc, nil
	}
	timeout := time.Duration(s.server.cfg.ConnectTimeoutSec * float64(time.Second))
	assoc, err := establishSocks5UDPAssociation(ctx, s.server.egress, timeout)
	if err != nil {
		return nil, err
	}
	s.socksAssoc = assoc
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		assoc.receiveLoop(func(payload []byte, ip net.IP, port int) error {
			return s.sendFrame(s.sessionID, payload, ip, port)
		})
	}()
	return assoc, nil
}

func (s *XUDPSession) sendViaSocks5(ctx context.Context, payload []byte, host string, port uint16) error {
	assoc, err := s.getOrCreateSocksAssoc(ctx)
	if err != nil {
		return err
	}
	return assoc.Send(host, port, payload)
}

func (s *XUDPSession) Close() {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return
	}
	s.closed = true
	if s.cancel != nil {
		s.cancel()
	}
	conns := make([]*net.UDPConn, 0, len(s.conns))
	for _, c := range s.conns {
		conns = append(conns, c)
	}
	s.conns = map[int]*net.UDPConn{}
	s.mu.Unlock()

	s.socksMu.Lock()
	assoc := s.socksAssoc
	s.socksAssoc = nil
	s.socksMu.Unlock()
	if assoc != nil {
		assoc.Close()
	}

	for _, c := range conns {
		c.Close()
	}
	s.wg.Wait()
}

type permissionError struct{ msg string }

func (e *permissionError) Error() string { return e.msg }
