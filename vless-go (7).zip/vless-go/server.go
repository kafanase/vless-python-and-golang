package main

import (
	"context"
	"crypto/subtle"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

type VlessServer struct {
	cfg      *Settings
	routing  *RoutingBlocklist
	geo      *GeoFilter
	abuse    *AbuseFilter
	egress   *EgressProxyConfig
	cfRanges *CloudflareRanges
	autoCert *autoCertManager

	udpEgressWarnOnce sync.Once
	upgrader          websocket.Upgrader
}

func newVlessServer(cfg *Settings, configDir string) (*VlessServer, error) {
	geo, err := newGeoFilter(cfg.GeoFilter, configDir)
	if err != nil {
		return nil, err
	}
	egress, err := loadEgressProxyConfig(cfg.EgressProxy)
	if err != nil {
		return nil, err
	}
	v := &VlessServer{
		cfg:     cfg,
		routing: newRoutingBlocklist(cfg.Routing, configDir),
		geo:     geo,
		abuse:   newAbuseFilter(cfg.AbuseFilter),
		egress:  egress,
	}
	if egress.Enabled && egress.Scope == "cloudflare_only" {
		v.cfRanges = newCloudflareRanges(cfg.EgressProxy, configDir)
	}
	if cfg.AutoCert {
		v.autoCert = newAutoCertManager(cfg.AutoCertRefreshSec, cfg.AutoCertTimeoutSec)
	}
	v.upgrader = websocket.Upgrader{
		ReadBufferSize:  4096,
		WriteBufferSize: 4096,
		CheckOrigin:     func(r *http.Request) bool { return true },
	}
	return v, nil
}

func peerIPFromRequest(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

func (v *VlessServer) httpHandler(w http.ResponseWriter, r *http.Request) {
	peerIP := peerIPFromRequest(r)

	allowed, country := v.geo.Allowed(peerIP)
	if !allowed {
		if logger != nil {
			c := country
			if c == "" {
				c = "unknown"
			}
			logger.Warn("GeoIP: отклонён клиент", "ip", peerIP, "country", c)
		}
		http.Error(w, "geo policy", http.StatusForbidden)
		return
	}
	if !v.routing.Ready() {
		http.Error(w, "routing list unavailable", http.StatusServiceUnavailable)
		return
	}

	conn, err := v.upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	conn.SetReadLimit(int64(v.cfg.MaxWSMessage))
	defer conn.Close()

	v.serveConn(conn, peerIP)
}

func (v *VlessServer) serveConn(conn *websocket.Conn, peerIP string) {
	var tcpConn net.Conn
	defer func() {
		if tcpConn != nil {
			tcpConn.Close()
		}
	}()

	handshakeDeadline := time.Now().Add(time.Duration(v.cfg.HandshakeTimeoutSec * float64(time.Second)))
	_ = conn.SetReadDeadline(handshakeDeadline)
	mt, message, err := conn.ReadMessage()
	if err != nil {
		if logger != nil {
			logger.Info("соединение закрыто", "peer", peerIP, "err", err)
		}
		return
	}
	if mt != websocket.BinaryMessage {
		if logger != nil {
			logger.Info("соединение закрыто", "peer", peerIP, "err", "VLESS handshake должен быть бинарным")
		}
		_ = conn.WriteControl(websocket.CloseMessage,
			websocket.FormatCloseMessage(1011, "connection failed"), time.Now().Add(2*time.Second))
		return
	}
	// снимаем дедлайн — дальше управляют connect/idle через отдельные операции
	_ = conn.SetReadDeadline(time.Time{})

	hs, err := parseVlessHandshake(message)
	if err != nil {
		v.closePolicy(conn, peerIP, err)
		return
	}
	if subtle.ConstantTimeCompare(hs.ClientID[:], v.cfg.UUIDBytes[:]) != 1 {
		v.closePolicy(conn, peerIP, errors.New("неверный UUID"))
		return
	}

	ctx := context.Background()

	if hs.Command == muxCommand {
		if normalizeDomain(hs.Host) != xudpMuxHost || hs.Port != xudpMuxPort {
			v.closeFailed(conn, peerIP, fmt.Errorf("неверное XUDP/MUX назначение: %s:%d", hs.Host, hs.Port))
			return
		}
		if err := conn.WriteMessage(websocket.BinaryMessage, []byte{hs.Version, 0}); err != nil {
			return
		}
		if err := v.handleXUDP(ctx, conn, message[hs.Offset:]); err != nil {
			if logger != nil && !isBenignCloseErr(err) {
				logger.Info("соединение закрыто", "peer", peerIP, "err", err)
			}
		}
		return
	}

	if v.routing.BlockedHost(hs.Host) {
		v.closePolicy(conn, peerIP, fmt.Errorf("назначение заблокировано routing-правилом: %s", hs.Host))
		return
	}
	if v.abuse.BlockedPort(hs.Port) {
		v.closePolicy(conn, peerIP, fmt.Errorf("порт назначения заблокирован анти-абуз фильтром: %d", hs.Port))
		return
	}
	initialPayload := message[hs.Offset:]
	if blocked, reason := v.abuse.SniffPayload(initialPayload); blocked {
		v.closePolicy(conn, peerIP, fmt.Errorf("заблокировано анти-абуз фильтром: %s", reason))
		return
	}

	connectTimeout := time.Duration(v.cfg.ConnectTimeoutSec * float64(time.Second))
	useEgressAll := v.egress != nil && v.egress.Enabled && v.egress.Scope == "all"

	if useEgressAll {
		// scope=all: DNS-резолвинг destination выполняет сам прокси, поэтому
		// локальный IP-based routing blocklist здесь не применяется (только
		// domain-правила выше, до захода в эту ветку).
		connectCtx, cancel := context.WithTimeout(ctx, connectTimeout)
		proxied, err := dialViaEgressProxy(connectCtx, v.egress, hs.Host, hs.Port, connectTimeout)
		cancel()
		if err != nil {
			v.closeFailed(conn, peerIP, err)
			return
		}
		tcpConn = proxied
	} else {
		// scope=cloudflare_only или egress выключен: в обоих случаях нужно
		// знать реальный IP назначения — резолвим локально.
		connectCtx, cancel := context.WithTimeout(ctx, connectTimeout)
		candidates, err := resolveTarget(connectCtx, hs.Host, hs.Port)
		cancel()
		if err != nil {
			v.closeFailed(conn, peerIP, err)
			return
		}
		var filtered []resolvedCandidate
		for _, c := range candidates {
			if !v.routing.BlockedIP(c.ip) {
				filtered = append(filtered, c)
			}
		}
		if len(filtered) == 0 {
			v.closePolicy(conn, peerIP, fmt.Errorf("адрес назначения заблокирован: %s", hs.Host))
			return
		}

		useEgressCF := v.egress != nil && v.egress.Enabled && v.egress.Scope == "cloudflare_only" &&
			v.cfRanges != nil && v.cfRanges.Contains(filtered[0].ip)

		if useEgressCF {
			connectCtx2, cancel2 := context.WithTimeout(ctx, connectTimeout)
			proxied, err := dialViaEgressProxy(connectCtx2, v.egress, filtered[0].ip.String(), hs.Port, connectTimeout)
			cancel2()
			if err != nil {
				v.closeFailed(conn, peerIP, err)
				return
			}
			tcpConn = proxied
			if logger != nil {
				logger.Info("egress через прокси: Cloudflare ASN", "host", hs.Host, "ip", filtered[0].ip.String())
			}
		} else {
			dialer := net.Dialer{Timeout: connectTimeout}
			var lastErr error
			for _, c := range filtered {
				network := "tcp4"
				if c.family == 6 {
					network = "tcp6"
				}
				addr := net.JoinHostPort(c.ip.String(), fmt.Sprintf("%d", hs.Port))
				conn2, derr := dialer.Dial(network, addr)
				if derr == nil {
					tcpConn = conn2
					break
				}
				lastErr = derr
			}
			if tcpConn == nil {
				v.closeFailed(conn, peerIP, fmt.Errorf("не удалось подключиться к %s:%d: %v", hs.Host, hs.Port, lastErr))
				return
			}
		}
	}

	if err := conn.WriteMessage(websocket.BinaryMessage, []byte{hs.Version, 0}); err != nil {
		return
	}
	if len(initialPayload) > 0 {
		if _, err := tcpConn.Write(initialPayload); err != nil {
			return
		}
	}

	var wg sync.WaitGroup
	wg.Add(2)
	errCh := make(chan error, 2)
	var writeMu sync.Mutex
	sniffPending := len(initialPayload) == 0 // сниффим первый чанк, если тела не было в handshake

	go func() {
		defer wg.Done()
		for {
			mt, chunk, err := conn.ReadMessage()
			if err != nil {
				errCh <- err
				return
			}
			if mt != websocket.BinaryMessage {
				errCh <- errors.New("текстовый WebSocket frame запрещён")
				return
			}
			if sniffPending {
				sniffPending = false
				if blocked, reason := v.abuse.SniffPayload(chunk); blocked {
					errCh <- fmt.Errorf("заблокировано анти-абуз фильтром: %s", reason)
					return
				}
			}
			if _, err := tcpConn.Write(chunk); err != nil {
				errCh <- err
				return
			}
		}
	}()

	go func() {
		defer wg.Done()
		buf := make([]byte, v.cfg.BufferSize)
		for {
			n, err := tcpConn.Read(buf)
			if n > 0 {
				writeMu.Lock()
				werr := conn.WriteMessage(websocket.BinaryMessage, buf[:n])
				writeMu.Unlock()
				if werr != nil {
					errCh <- werr
					return
				}
			}
			if err != nil {
				errCh <- err
				return
			}
		}
	}()

	firstErr := <-errCh
	tcpConn.Close()
	_ = conn.Close()
	wg.Wait()
	if firstErr != nil && logger != nil && !isBenignCloseErr(firstErr) {
		logger.Info("соединение закрыто", "peer", peerIP, "err", firstErr)
	}
}

func isBenignCloseErr(err error) bool {
	if err == nil {
		return true
	}
	if errors.Is(err, io.EOF) {
		return true
	}
	if websocket.IsCloseError(err, websocket.CloseNormalClosure, websocket.CloseGoingAway, websocket.CloseNoStatusReceived) {
		return true
	}
	return false
}

func (v *VlessServer) closePolicy(conn *websocket.Conn, peerIP string, cause error) {
	if logger != nil {
		logger.Warn(peerIP, "err", cause)
	}
	_ = conn.WriteControl(websocket.CloseMessage,
		websocket.FormatCloseMessage(1008, "policy violation"), time.Now().Add(2*time.Second))
}

func (v *VlessServer) closeFailed(conn *websocket.Conn, peerIP string, cause error) {
	if logger != nil && !isBenignCloseErr(cause) {
		logger.Info("соединение закрыто", "peer", peerIP, "err", cause)
	}
	_ = conn.WriteControl(websocket.CloseMessage,
		websocket.FormatCloseMessage(1011, "connection failed"), time.Now().Add(2*time.Second))
}

func (v *VlessServer) tlsConfig() (*tls.Config, error) {
	allowedSNI := map[string]bool{}
	for _, s := range v.cfg.SNI {
		allowedSNI[s] = true
	}
	cfg := &tls.Config{
		MinVersion: tls.VersionTLS12,
	}

	if v.cfg.AutoCert {
		// Сертификат/ключ живут только в памяти (autoCertManager), на диск
		// ничего не пишется. cfg.Certificates намеренно не заполняется.
		cfg.GetCertificate = v.autoCert.GetCertificate
	} else {
		cert, err := tls.LoadX509KeyPair(v.cfg.CertFile, v.cfg.KeyFile)
		if err != nil {
			return nil, err
		}
		cfg.Certificates = []tls.Certificate{cert}
	}

	if len(allowedSNI) > 0 {
		cfg.GetConfigForClient = func(hello *tls.ClientHelloInfo) (*tls.Config, error) {
			normalized := strings.TrimRight(strings.ToLower(hello.ServerName), ".")
			if !allowedSNI[normalized] {
				if logger != nil {
					logger.Warn("отклонён SNI", "sni", hello.ServerName)
				}
				return nil, fmt.Errorf("unrecognized_name")
			}
			return nil, nil // использовать исходный tls.Config
		}
	}
	return cfg, nil
}

func (v *VlessServer) Run(ctx context.Context) error {
	if err := v.geo.Open(ctx); err != nil {
		return err
	}
	v.routing.Start(ctx)

	if v.cfg.AutoCert {
		if err := v.autoCert.Start(ctx); err != nil {
			v.routing.Stop()
			v.geo.Close()
			return err
		}
	}

	if v.cfRanges != nil {
		if err := v.cfRanges.Start(ctx); err != nil {
			v.routing.Stop()
			v.geo.Close()
			if v.cfg.AutoCert {
				v.autoCert.Stop()
			}
			return err
		}
	}

	tlsCfg, err := v.tlsConfig()
	if err != nil {
		v.routing.Stop()
		v.geo.Close()
		if v.cfg.AutoCert {
			v.autoCert.Stop()
		}
		if v.cfRanges != nil {
			v.cfRanges.Stop()
		}
		return err
	}

	addr := net.JoinHostPort(v.cfg.ListenHost, fmt.Sprintf("%d", v.cfg.Port))
	ln, err := tls.Listen("tcp", addr, tlsCfg)
	if err != nil {
		v.routing.Stop()
		v.geo.Close()
		if v.cfg.AutoCert {
			v.autoCert.Stop()
		}
		if v.cfRanges != nil {
			v.cfRanges.Stop()
		}
		return err
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/", v.httpHandler)
	srv := &http.Server{Handler: mux}

	serveErrCh := make(chan error, 1)
	go func() {
		serveErrCh <- srv.Serve(ln)
	}()

	sniList := "любой"
	if len(v.cfg.SNI) > 0 {
		sniList = strings.Join(v.cfg.SNI, ",")
	}
	if logger != nil {
		logger.Info("VLESS/WSS слушает", "addr", addr, "sni", sniList)
	}

	select {
	case <-ctx.Done():
	case err := <-serveErrCh:
		if err != nil && !errors.Is(err, http.ErrServerClosed) && logger != nil {
			logger.Error("сервер остановлен с ошибкой", "err", err)
		}
	}

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = srv.Shutdown(shutdownCtx)

	v.routing.Stop()
	v.geo.Close()
	if v.cfg.AutoCert {
		v.autoCert.Stop()
	}
	if v.cfRanges != nil {
		v.cfRanges.Stop()
	}
	return nil
}
