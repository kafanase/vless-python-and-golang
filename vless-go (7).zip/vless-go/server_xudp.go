package main

import (
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"sync"

	"github.com/gorilla/websocket"
)

// handleXUDP обслуживает совместимый с sing-box/Xray XUDP поверх MUX-потока.
func (v *VlessServer) handleXUDP(ctx context.Context, conn *websocket.Conn, initial []byte) error {
	stream := newWSByteStream(conn, initial)
	sessions := map[uint16]*XUDPSession{}
	var sessionsMu sync.Mutex
	var sendMu sync.Mutex

	sendPacket := func(sessionID uint16, payload []byte, srcIP net.IP, srcPort int) error {
		address, err := encodeXudpAddress(srcIP.String(), uint16(srcPort))
		if err != nil {
			return err
		}
		metadata := make([]byte, 0, 4+len(address))
		metadata = binary.BigEndian.AppendUint16(metadata, sessionID)
		metadata = append(metadata, xudpStatusKeep, xudpOptionData)
		metadata = append(metadata, xudpNetworkUDP)
		metadata = append(metadata, address...)

		frame := make([]byte, 0, 2+len(metadata)+2+len(payload))
		frame = binary.BigEndian.AppendUint16(frame, uint16(len(metadata)))
		frame = append(frame, metadata...)
		frame = binary.BigEndian.AppendUint16(frame, uint16(len(payload)))
		frame = append(frame, payload...)

		sendMu.Lock()
		defer sendMu.Unlock()
		return conn.WriteMessage(websocket.BinaryMessage, frame)
	}

	sendClose := func(sessionID uint16, errFlag bool) error {
		option := byte(0)
		if errFlag {
			option = xudpOptionError
		}
		frame := make([]byte, 0, 6)
		frame = binary.BigEndian.AppendUint16(frame, 4)
		frame = binary.BigEndian.AppendUint16(frame, sessionID)
		frame = append(frame, xudpStatusEnd, option)
		sendMu.Lock()
		defer sendMu.Unlock()
		return conn.WriteMessage(websocket.BinaryMessage, frame)
	}

	closeAll := func() {
		sessionsMu.Lock()
		list := make([]*XUDPSession, 0, len(sessions))
		for _, s := range sessions {
			list = append(list, s)
		}
		sessionsMu.Unlock()
		for _, s := range list {
			s.Close()
		}
	}
	defer closeAll()

	for {
		lenBuf, err := stream.readExactly(2)
		if err != nil {
			return err
		}
		metadataLength := int(binary.BigEndian.Uint16(lenBuf))
		if metadataLength < 4 || metadataLength > 1024 {
			return fmt.Errorf("неверная длина XUDP metadata: %d", metadataLength)
		}
		metadata, err := stream.readExactly(metadataLength)
		if err != nil {
			return err
		}
		sessionID := binary.BigEndian.Uint16(metadata[0:2])
		status := metadata[2]
		option := metadata[3]

		var destHost string
		var destPort uint16
		hasDest := false
		if metadataLength > 4 {
			network := metadata[4]
			if network != xudpNetworkUDP {
				return fmt.Errorf("XUDP поддерживает только UDP network=2, получено %d", network)
			}
			host, port, _, aerr := parseXudpAddress(metadata, 5)
			if aerr != nil {
				return aerr
			}
			destHost, destPort, hasDest = host, port, true
			// Остаток metadata намеренно игнорируется (8-byte global ID у Xray).
		}

		sessionsMu.Lock()
		session := sessions[sessionID]
		sessionsMu.Unlock()

		switch status {
		case xudpStatusNew:
			if !hasDest {
				return fmt.Errorf("XUDP NEW без назначения")
			}
			if session != nil {
				session.Close()
			}
			session = newXUDPSession(sessionID, v, sendPacket)
			session.hasDefault = true
			session.defaultHost, session.defaultPort = destHost, destPort
			sessionsMu.Lock()
			sessions[sessionID] = session
			sessionsMu.Unlock()
		case xudpStatusKeep:
			if session == nil {
				_ = sendClose(sessionID, true)
				if option&xudpOptionData != 0 {
					plenBuf, err := stream.readExactly(2)
					if err != nil {
						return err
					}
					plen := int(binary.BigEndian.Uint16(plenBuf))
					if _, err := stream.readExactly(plen); err != nil {
						return err
					}
				}
				continue
			}
		case xudpStatusEnd:
			if session != nil {
				sessionsMu.Lock()
				delete(sessions, sessionID)
				sessionsMu.Unlock()
				session.Close()
			}
			continue
		case xudpStatusKeepalive:
			continue
		default:
			return fmt.Errorf("неизвестный XUDP status: %d", status)
		}

		if option&xudpOptionError != 0 {
			if session != nil {
				sessionsMu.Lock()
				delete(sessions, sessionID)
				sessionsMu.Unlock()
				session.Close()
			}
			continue
		}
		if option&xudpOptionData != 0 {
			plenBuf, err := stream.readExactly(2)
			if err != nil {
				return err
			}
			plen := int(binary.BigEndian.Uint16(plenBuf))
			payload, err := stream.readExactly(plen)
			if err != nil {
				return err
			}
			if session == nil {
				continue
			}
			if err := session.Send(ctx, payload, destHost, destPort, hasDest); err != nil {
				if logger != nil {
					logger.Warn("XUDP session error", "session", sessionID, "err", err)
				}
				sessionsMu.Lock()
				delete(sessions, sessionID)
				sessionsMu.Unlock()
				session.Close()
				_ = sendClose(sessionID, true)
			}
		}
	}
}
