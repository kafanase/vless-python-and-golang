package main

import (
	"encoding/hex"
	"fmt"
	"strings"
)

// parseUUID разбирает строку UUID (с дефисами или без) в 16 байт.
func parseUUID(s string) ([16]byte, error) {
	var out [16]byte
	clean := strings.ReplaceAll(strings.TrimSpace(s), "-", "")
	clean = strings.TrimPrefix(clean, "urn:uuid:")
	if len(clean) != 32 {
		return out, fmt.Errorf("неверный формат UUID: %q", s)
	}
	b, err := hex.DecodeString(clean)
	if err != nil {
		return out, fmt.Errorf("неверный формат UUID: %q: %w", s, err)
	}
	copy(out[:], b)
	return out, nil
}
