package main

import (
	"errors"

	"github.com/gorilla/websocket"
)

// wsByteStream аналог WebSocketByteStream: превращает бинарные WebSocket
// сообщения в непрерывный байтовый поток с readExactly.
type wsByteStream struct {
	conn   *websocket.Conn
	buffer []byte
}

func newWSByteStream(conn *websocket.Conn, initial []byte) *wsByteStream {
	buf := make([]byte, len(initial))
	copy(buf, initial)
	return &wsByteStream{conn: conn, buffer: buf}
}

func (s *wsByteStream) readExactly(n int) ([]byte, error) {
	if n < 0 {
		return nil, errors.New("отрицательная длина")
	}
	for len(s.buffer) < n {
		mt, data, err := s.conn.ReadMessage()
		if err != nil {
			return nil, err
		}
		if mt != websocket.BinaryMessage {
			return nil, errors.New("текстовый WebSocket frame запрещён")
		}
		s.buffer = append(s.buffer, data...)
	}
	out := make([]byte, n)
	copy(out, s.buffer[:n])
	s.buffer = s.buffer[n:]
	return out, nil
}
