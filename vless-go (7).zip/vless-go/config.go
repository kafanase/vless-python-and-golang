package main

import (
	"fmt"
	"io"
	"io/fs"
	"log"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
)

type Settings struct {
	UUIDBytes           [16]byte
	ListenHost          string
	Port                int
	SNI                 []string
	CertFile            string
	KeyFile             string
	AutoCert            bool
	AutoCertRefreshSec  int
	AutoCertTimeoutSec  float64
	HandshakeTimeoutSec float64
	ConnectTimeoutSec   float64
	IdleTimeoutSec      float64
	BufferSize          int
	MaxWSMessage        int
	Routing             map[string]any
	GeoFilter           map[string]any
	AbuseFilter         map[string]any
	EgressProxy         map[string]any
	LoggingCfg          map[string]any
}

func loadConfig(path string) (*Settings, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, &ConfigError{msg: fmt.Sprintf("не удалось прочитать %s: %v", path, err)}
	}
	raw, err := yamlParse(string(data))
	if err != nil {
		return nil, &ConfigError{msg: fmt.Sprintf("не удалось прочитать %s: %v", path, err)}
	}
	absPath, err := filepath.Abs(path)
	if err != nil {
		return nil, &ConfigError{msg: err.Error()}
	}
	base := filepath.Dir(absPath)

	server := asMap(raw["server"])
	tls := asMap(raw["tls"])
	limits := asMap(raw["limits"])

	uuidRaw, ok := raw["uuid"]
	if !ok || uuidRaw == nil {
		return nil, configErrorf("ошибка обязательной настройки: 'uuid'")
	}
	uuidBytes, err := parseUUID(toStr(uuidRaw, ""))
	if err != nil {
		return nil, configErrorf("ошибка обязательной настройки: %v", err)
	}

	port := toInt(server["port"], 25323)
	if port < 1 || port > 65535 {
		return nil, configErrorf("ошибка обязательной настройки: порт вне диапазона 1..65535")
	}

	certRaw, hasCert := tls["certfile"]
	keyRaw, hasKey := tls["keyfile"]
	autoCert := toBool(tls["auto_cert"], false)
	var certFile, keyFile string
	if autoCert {
		// В режиме auto_cert certfile/keyfile не обязательны — сертификат и
		// ключ получаются с удалённого сервера и хранятся только в памяти.
		if hasCert && certRaw != nil {
			certFile = resolvePath(base, toStr(certRaw, ""))
		}
		if hasKey && keyRaw != nil {
			keyFile = resolvePath(base, toStr(keyRaw, ""))
		}
	} else {
		if !hasCert || certRaw == nil {
			return nil, configErrorf("ошибка обязательной настройки: 'certfile'")
		}
		if !hasKey || keyRaw == nil {
			return nil, configErrorf("ошибка обязательной настройки: 'keyfile'")
		}
		certFile = resolvePath(base, toStr(certRaw, ""))
		keyFile = resolvePath(base, toStr(keyRaw, ""))
	}

	var sniList []string
	for _, s := range toStrList(tls["sni"]) {
		s = strings.ToLower(strings.TrimSpace(s))
		s = strings.TrimRight(s, ".")
		if s != "" {
			sniList = append(sniList, s)
		}
	}

	bufferSize := toInt(limits["buffer_size"], 65536)
	if bufferSize < 4096 {
		bufferSize = 4096
	}
	if bufferSize > 1048576 {
		bufferSize = 1048576
	}
	maxWSMessage := toInt(limits["max_ws_message"], 1048576)
	if maxWSMessage < 1024 {
		maxWSMessage = 1024
	}

	return &Settings{
		UUIDBytes:           uuidBytes,
		ListenHost:          toStr(server["host"], "0.0.0.0"),
		Port:                port,
		SNI:                 sniList,
		CertFile:            certFile,
		KeyFile:             keyFile,
		AutoCert:            autoCert,
		AutoCertRefreshSec:  toInt(tls["auto_cert_refresh_seconds"], 21600),
		AutoCertTimeoutSec:  toFloat(tls["auto_cert_timeout"], 15),
		HandshakeTimeoutSec: toFloat(limits["handshake_timeout"], 10),
		ConnectTimeoutSec:   toFloat(limits["connect_timeout"], 10),
		IdleTimeoutSec:      toFloat(limits["idle_timeout"], 300),
		BufferSize:          bufferSize,
		MaxWSMessage:        maxWSMessage,
		Routing:             asMap(raw["routing"]),
		GeoFilter:           asMap(raw["geofilter"]),
		AbuseFilter:         asMap(raw["abuse_filter"]),
		EgressProxy:         asMap(raw["egress_proxy"]),
		LoggingCfg:          asMap(raw["logging"]),
	}, nil
}

func resolvePath(base, p string) string {
	if p == "" {
		return ""
	}
	if filepath.IsAbs(p) {
		abs, err := filepath.Abs(p)
		if err == nil {
			return abs
		}
		return p
	}
	abs, err := filepath.Abs(filepath.Join(base, p))
	if err == nil {
		return abs
	}
	return filepath.Join(base, p)
}

var logger *slog.Logger

func configureLogging(cfg map[string]any) {
	levelStr := strings.ToUpper(toStr(cfg["level"], "INFO"))
	var level slog.Level
	switch levelStr {
	case "DEBUG":
		level = slog.LevelDebug
	case "WARNING", "WARN":
		level = slog.LevelWarn
	case "ERROR", "CRITICAL", "FATAL":
		level = slog.LevelError
	default:
		level = slog.LevelInfo
	}

	var writers []io.Writer
	writers = append(writers, os.Stderr)
	if f := toStr(cfg["file"], ""); f != "" {
		fh, err := os.OpenFile(f, os.O_CREATE|os.O_WRONLY|os.O_APPEND, fs.FileMode(0o644))
		if err == nil {
			writers = append(writers, fh)
		} else {
			log.Printf("не удалось открыть лог-файл %s: %v", f, err)
		}
	}

	handler := slog.NewTextHandler(io.MultiWriter(writers...), &slog.HandlerOptions{Level: level})
	logger = slog.New(handler)
	slog.SetDefault(logger)
}
