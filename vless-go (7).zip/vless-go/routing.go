package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"
)

// ---------- парсинг правил (аналог parse_routing_rules) ----------

type routingRules struct {
	networks          []*net.IPNet
	domains           map[string]bool
	fullDomains       map[string]bool
	keywords          []string
	regexps           []*regexp.Regexp
	skippedReferences []string
}

func walkJSONStrings(v any, out *[]string) {
	switch t := v.(type) {
	case string:
		*out = append(*out, t)
	case []any:
		for _, item := range t {
			walkJSONStrings(item, out)
		}
	case map[string]any:
		for _, item := range t {
			walkJSONStrings(item, out)
		}
	}
}

// parseIPNetworkLoose аналог ipaddress.ip_network(token, strict=False): токен
// без "/" трактуется как одиночный адрес.
func parseIPNetworkLoose(token string) (*net.IPNet, error) {
	if !strings.Contains(token, "/") {
		ip := net.ParseIP(token)
		if ip == nil {
			return nil, fmt.Errorf("не IP/CIDR")
		}
		if ip4 := ip.To4(); ip4 != nil {
			return &net.IPNet{IP: ip4, Mask: net.CIDRMask(32, 32)}, nil
		}
		return &net.IPNet{IP: ip.To16(), Mask: net.CIDRMask(128, 128)}, nil
	}
	ip, network, err := net.ParseCIDR(token)
	if err != nil {
		return nil, err
	}
	if ip4 := ip.To4(); ip4 != nil && network.IP.To4() != nil {
		network.IP = network.IP.To4()
	}
	return network, nil
}

func parseRoutingRules(data []byte) (*routingRules, error) {
	text := stripUTF8BOM(data)
	var candidates []string
	var parsed any
	dec := json.NewDecoder(bytes.NewReader(text))
	if err := dec.Decode(&parsed); err == nil {
		walkJSONStrings(parsed, &candidates)
	} else {
		sc := bufio.NewScanner(bytes.NewReader(text))
		sc.Buffer(make([]byte, 0, 64*1024), 16*1024*1024)
		for sc.Scan() {
			candidates = append(candidates, sc.Text())
		}
	}

	netSet := map[string]*net.IPNet{}
	domains := map[string]bool{}
	fullDomains := map[string]bool{}
	keywords := map[string]bool{}
	var regexps []*regexp.Regexp
	skipped := map[string]bool{}

	for _, raw := range candidates {
		line := raw
		if idx := strings.Index(line, "#"); idx >= 0 {
			line = line[:idx]
		}
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		lowered := strings.ToLower(line)
		switch {
		case strings.HasPrefix(lowered, "geosite:"), strings.HasPrefix(lowered, "include:"):
			skipped[line] = true
			continue
		case strings.HasPrefix(lowered, "regexp:"):
			expr := strings.TrimSpace(line[len("regexp:"):])
			re, err := regexp.Compile("(?i)" + expr)
			if err != nil {
				if logger != nil {
					logger.Warn("пропущено неверное regexp-правило", "expr", expr, "err", err)
				}
				continue
			}
			regexps = append(regexps, re)
			continue
		case strings.HasPrefix(lowered, "keyword:"):
			kw := normalizeDomain(strings.TrimSpace(line[len("keyword:"):]))
			if kw != "" {
				keywords[kw] = true
			}
			continue
		case strings.HasPrefix(lowered, "full:"):
			d := normalizeDomain(strings.TrimSpace(line[len("full:"):]))
			if d != "" {
				fullDomains[d] = true
			}
			continue
		case strings.HasPrefix(lowered, "domain:"):
			line = strings.TrimSpace(line[len("domain:"):])
		}

		token := strings.Trim(line, "[](){}\"'")
		if net_, err := parseIPNetworkLoose(token); err == nil {
			netSet[net_.String()] = net_
			continue
		}
		domain := normalizeDomain(token)
		if domain != "" && strings.Contains(domain, ".") && !strings.Contains(domain, " ") {
			domains[domain] = true
		}
	}

	networks := make([]*net.IPNet, 0, len(netSet))
	for _, n := range netSet {
		networks = append(networks, n)
	}
	sort.Slice(networks, func(i, j int) bool {
		vi, vj := netVersion(networks[i]), netVersion(networks[j])
		if vi != vj {
			return vi < vj
		}
		ci := new(big.Int).SetBytes(networks[i].IP)
		cj := new(big.Int).SetBytes(networks[j].IP)
		if cmp := ci.Cmp(cj); cmp != 0 {
			return cmp < 0
		}
		pi, _ := networks[i].Mask.Size()
		pj, _ := networks[j].Mask.Size()
		return pi < pj
	})

	kwList := make([]string, 0, len(keywords))
	for k := range keywords {
		kwList = append(kwList, k)
	}
	sort.Strings(kwList)
	skipList := make([]string, 0, len(skipped))
	for s := range skipped {
		skipList = append(skipList, s)
	}
	sort.Strings(skipList)

	return &routingRules{
		networks:          networks,
		domains:           domains,
		fullDomains:       fullDomains,
		keywords:          kwList,
		regexps:           regexps,
		skippedReferences: skipList,
	}, nil
}

func netVersion(n *net.IPNet) int {
	if n.IP.To4() != nil {
		return 4
	}
	return 6
}

func stripUTF8BOM(data []byte) []byte {
	if len(data) >= 3 && data[0] == 0xEF && data[1] == 0xBB && data[2] == 0xBF {
		return data[3:]
	}
	return data
}

// ---------- RoutingBlocklist ----------

type RoutingBlocklist struct {
	enabled        bool
	url            string
	refreshSeconds int
	timeout        time.Duration
	failClosed     bool
	cacheFile      string

	mu          sync.RWMutex
	v4          []*net.IPNet
	v6          []*net.IPNet
	domains     map[string]bool
	fullDomains map[string]bool
	keywords    []string
	regexps     []*regexp.Regexp
	ready       bool

	cancel context.CancelFunc
	done   chan struct{}
}

func newRoutingBlocklist(cfg map[string]any, baseDir string) *RoutingBlocklist {
	enabled := toBool(cfg["enabled"], true)
	failClosed := toBool(cfg["fail_closed"], false)
	rb := &RoutingBlocklist{
		enabled:        enabled,
		url:            toStr(cfg["source_url"], "https://javascript.publicvm.com:2087/routing"),
		refreshSeconds: toInt(cfg["refresh_seconds"], 3600),
		timeout:        time.Duration(toFloat(cfg["download_timeout"], 15) * float64(time.Second)),
		failClosed:     failClosed,
		cacheFile:      resolvePath(baseDir, toStr(cfg["cache_file"], "routing.cache")),
		domains:        map[string]bool{},
		fullDomains:    map[string]bool{},
	}
	rb.ready = !(enabled && failClosed)
	return rb
}

func (rb *RoutingBlocklist) Ready() bool {
	rb.mu.RLock()
	defer rb.mu.RUnlock()
	return rb.ready
}

func (rb *RoutingBlocklist) BlockedIP(ip net.IP) bool {
	rb.mu.RLock()
	defer rb.mu.RUnlock()
	var nets []*net.IPNet
	if ip.To4() != nil {
		nets = rb.v4
	} else {
		nets = rb.v6
	}
	for _, n := range nets {
		if n.Contains(ip) {
			return true
		}
	}
	return false
}

func (rb *RoutingBlocklist) BlockedHost(host string) bool {
	if ip := net.ParseIP(host); ip != nil {
		return rb.BlockedIP(ip)
	}
	domain := normalizeDomain(host)

	rb.mu.RLock()
	defer rb.mu.RUnlock()
	if rb.fullDomains[domain] {
		return true
	}
	labels := strings.Split(domain, ".")
	limit := len(labels) - 1
	if limit < 1 {
		limit = 1
	}
	for i := 0; i < limit; i++ {
		if rb.domains[strings.Join(labels[i:], ".")] {
			return true
		}
	}
	for _, kw := range rb.keywords {
		if strings.Contains(domain, kw) {
			return true
		}
	}
	for _, re := range rb.regexps {
		if re.MatchString(domain) {
			return true
		}
	}
	return false
}

func (rb *RoutingBlocklist) install(rules *routingRules) {
	var v4, v6 []*net.IPNet
	for _, n := range rules.networks {
		if netVersion(n) == 4 {
			v4 = append(v4, n)
		} else {
			v6 = append(v6, n)
		}
	}
	rb.mu.Lock()
	rb.v4 = v4
	rb.v6 = v6
	rb.domains = rules.domains
	rb.fullDomains = rules.fullDomains
	rb.keywords = rules.keywords
	rb.regexps = rules.regexps
	rb.ready = true
	rb.mu.Unlock()

	if logger != nil {
		logger.Info("routing", "domains", len(rules.domains), "full", len(rules.fullDomains),
			"keywords", len(rules.keywords), "regexp", len(rules.regexps), "ipv4", len(v4), "ipv6", len(v6))
		if len(rules.skippedReferences) > 0 {
			logger.Warn("пропущены внешние ссылки geosite/include", "refs", strings.Join(rules.skippedReferences, ", "))
		}
	}
}

func (rb *RoutingBlocklist) download(ctx context.Context) ([]byte, error) {
	ctx, cancel := context.WithTimeout(ctx, rb.timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rb.url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "vless-ws/2.0")
	req.Header.Set("Accept", "application/json,text/plain,*/*")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 32*1024*1024))
}

func (rb *RoutingBlocklist) Refresh(ctx context.Context) {
	if !rb.enabled {
		rb.mu.Lock()
		rb.ready = true
		rb.mu.Unlock()
		return
	}
	data, err := rb.download(ctx)
	if err == nil {
		var rules *routingRules
		rules, err = parseRoutingRules(data)
		if err == nil {
			if len(rules.networks) == 0 && len(rules.domains) == 0 && len(rules.fullDomains) == 0 &&
				len(rules.keywords) == 0 && len(rules.regexps) == 0 {
				err = errors.New("источник не содержит поддерживаемых routing-правил")
			}
		}
		if err == nil {
			rb.install(rules)
			if werr := atomicWrite(rb.cacheFile, data); werr != nil && logger != nil {
				logger.Warn("не удалось записать кэш routing", "err", werr)
			}
			return
		}
	}
	if logger != nil {
		logger.Warn("не удалось обновить routing blocklist", "err", err)
	}
	if data, cerr := os.ReadFile(rb.cacheFile); cerr == nil {
		if rules, perr := parseRoutingRules(data); perr == nil {
			if len(rules.networks) > 0 || len(rules.domains) > 0 || len(rules.fullDomains) > 0 ||
				len(rules.keywords) > 0 || len(rules.regexps) > 0 {
				rb.install(rules)
				if logger != nil {
					logger.Info("использован кэш", "file", rb.cacheFile)
				}
			}
		} else if logger != nil {
			logger.Error("ошибка кэша routing", "err", perr)
		}
	}
}

func atomicWrite(path string, data []byte) error {
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".tmp-*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	if _, err := tmp.Write(data); err != nil {
		tmp.Close()
		os.Remove(tmpName)
		return err
	}
	if err := tmp.Close(); err != nil {
		os.Remove(tmpName)
		return err
	}
	return os.Rename(tmpName, path)
}

func (rb *RoutingBlocklist) run(ctx context.Context) {
	defer close(rb.done)
	rb.Refresh(ctx)
	if rb.refreshSeconds <= 0 {
		return
	}
	interval := time.Duration(rb.refreshSeconds) * time.Second
	if interval < 60*time.Second {
		interval = 60 * time.Second
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			rb.Refresh(ctx)
		}
	}
}

func (rb *RoutingBlocklist) Start(parent context.Context) {
	if !rb.enabled {
		return
	}
	ctx, cancel := context.WithCancel(parent)
	rb.cancel = cancel
	rb.done = make(chan struct{})
	go rb.run(ctx)
}

func (rb *RoutingBlocklist) Stop() {
	if rb.cancel != nil {
		rb.cancel()
		<-rb.done
	}
}
