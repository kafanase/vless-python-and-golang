package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"sync"
	"time"
)

// socks5UDPAssociation — одна активная UDP ASSOCIATE-ассоциация SOCKS5:
// TCP control-соединение (должно оставаться открытым, пока ассоциация
// нужна — большинство серверов рвут relay при закрытии control-канала) +
// локальный UDP-сокет, через который данные шлются на relay-адрес,
// полученный от прокси в ответе на UDP ASSOCIATE.
type socks5UDPAssociation struct {
	controlConn net.Conn
	udpConn     *net.UDPConn
	relayAddr   *net.UDPAddr

	mu sync.Mutex
}

// establishSocks5UDPAssociation поднимает control-соединение к SOCKS5-прокси,
// выполняет greeting/auth и команду UDP ASSOCIATE, возвращая готовую к
// использованию ассоциацию.
func establishSocks5UDPAssociation(ctx context.Context, cfg *EgressProxyConfig, timeout time.Duration) (*socks5UDPAssociation, error) {
	udpConn, err := net.ListenUDP("udp", &net.UDPAddr{})
	if err != nil {
		return nil, fmt.Errorf("локальный UDP-сокет для SOCKS5 UDP ASSOCIATE: %w", err)
	}
	localPort := udpConn.LocalAddr().(*net.UDPAddr).Port

	dialer := net.Dialer{Timeout: timeout}
	proxyAddr := net.JoinHostPort(cfg.Host, fmt.Sprintf("%d", cfg.Port))
	raw, err := dialer.DialContext(ctx, "tcp", proxyAddr)
	if err != nil {
		udpConn.Close()
		return nil, fmt.Errorf("не удалось подключиться к egress-прокси %s: %w", proxyAddr, err)
	}

	var conn net.Conn = raw
	if cfg.TLS {
		tlsCfg, err := buildProxyTLSConfig(cfg)
		if err != nil {
			raw.Close()
			udpConn.Close()
			return nil, err
		}
		tlsConn := tls.Client(raw, tlsCfg)
		hsCtx, cancel := context.WithTimeout(ctx, timeout)
		herr := tlsConn.HandshakeContext(hsCtx)
		cancel()
		if herr != nil {
			raw.Close()
			udpConn.Close()
			return nil, fmt.Errorf("TLS-handshake с egress-прокси %s: %w", proxyAddr, herr)
		}
		conn = tlsConn
	}

	_ = conn.SetDeadline(time.Now().Add(timeout))

	if err := socks5GreetAndAuth(conn, cfg); err != nil {
		conn.Close()
		udpConn.Close()
		return nil, err
	}
	// DST.ADDR/DST.PORT в запросе UDP ASSOCIATE — адрес, с которого клиент
	// планирует слать UDP-датаграммы; 0.0.0.0 с реальным локальным портом
	// принимается подавляющим большинством реализаций.
	bndHost, bndPort, err := socks5Request(conn, 0x03, "0.0.0.0", uint16(localPort))
	if err != nil {
		conn.Close()
		udpConn.Close()
		return nil, err
	}
	_ = conn.SetDeadline(time.Time{}) // control-соединение держим открытым без таймаута

	relayHost := bndHost
	if relayHost == "" || relayHost == "0.0.0.0" || relayHost == "::" {
		// Некоторые серверы возвращают неопределённый адрес вместо
		// собственного — в этом случае шлём на адрес самого прокси.
		relayHost = cfg.Host
	}
	relayAddr, err := net.ResolveUDPAddr("udp", net.JoinHostPort(relayHost, fmt.Sprintf("%d", bndPort)))
	if err != nil {
		conn.Close()
		udpConn.Close()
		return nil, fmt.Errorf("резолвинг UDP relay-адреса SOCKS5: %w", err)
	}

	return &socks5UDPAssociation{controlConn: conn, udpConn: udpConn, relayAddr: relayAddr}, nil
}

// Send заворачивает payload в SOCKS5 UDP-заголовок (RSV(2)+FRAG(1)+ATYP+
// ADDR+PORT) и отправляет на relay.
func (a *socks5UDPAssociation) Send(host string, port uint16, payload []byte) error {
	addrBytes, err := socks5EncodeAddress(host)
	if err != nil {
		return err
	}
	packet := make([]byte, 0, 3+len(addrBytes)+2+len(payload))
	packet = append(packet, 0x00, 0x00, 0x00) // RSV, RSV, FRAG=0 (без фрагментации)
	packet = append(packet, addrBytes...)
	packet = append(packet, byte(port>>8), byte(port))
	packet = append(packet, payload...)

	a.mu.Lock()
	_, err = a.udpConn.WriteToUDP(packet, a.relayAddr)
	a.mu.Unlock()
	return err
}

// receiveLoop читает датаграммы от relay, разбирает SOCKS5 UDP-заголовок и
// отдаёт (payload, srcIP, srcPort) в колбэк — до первой ошибки чтения или
// до того, как колбэк сам вернёт ошибку.
func (a *socks5UDPAssociation) receiveLoop(onPacket func(payload []byte, srcIP net.IP, srcPort int) error) {
	buf := make([]byte, 65535+32)
	for {
		n, _, err := a.udpConn.ReadFromUDP(buf)
		if err != nil {
			return
		}
		if n < 4 || buf[2] != 0x00 {
			continue // слишком короткий пакет или фрагментация (не поддерживаем)
		}
		atyp := buf[3]
		pos := 4
		var host string
		switch atyp {
		case 0x01:
			if n < pos+4+2 {
				continue
			}
			host = net.IP(buf[pos : pos+4]).String()
			pos += 4
		case 0x03:
			if pos >= n {
				continue
			}
			l := int(buf[pos])
			pos++
			if pos+l+2 > n {
				continue
			}
			host = string(buf[pos : pos+l])
			pos += l
		case 0x04:
			if n < pos+16+2 {
				continue
			}
			host = net.IP(buf[pos : pos+16]).String()
			pos += 16
		default:
			continue
		}
		if pos+2 > n {
			continue
		}
		port := int(buf[pos])<<8 | int(buf[pos+1])
		pos += 2

		ip := net.ParseIP(host)
		if ip == nil {
			// Домен вместо IP в обратном пакете — нестандартно для ответов
			// relay, корректно передать в XUDP-фрейм не можем — пропускаем.
			continue
		}
		payload := make([]byte, n-pos)
		copy(payload, buf[pos:n])
		if err := onPacket(payload, ip, port); err != nil {
			return
		}
	}
}

func (a *socks5UDPAssociation) Close() {
	a.controlConn.Close()
	a.udpConn.Close()
}
