package main

import (
	"errors"
	"strings"
)

// Минимальная реализация Punycode (RFC 3492) и IDNA ToASCII/ToUnicode по
// меткам домена (без полной IDNA2008-нормализации — этого достаточно для
// доменов, встречающихся в VLESS handshake/SNI).

const (
	puncBase        = 36
	puncTMin        = 1
	puncTMax        = 26
	puncSkew        = 38
	puncDamp        = 700
	puncInitialBias = 72
	puncInitialN    = 128
)

func punycodeAdapt(delta, numPoints int, firstTime bool) int {
	if firstTime {
		delta /= puncDamp
	} else {
		delta /= 2
	}
	delta += delta / numPoints
	k := 0
	for delta > ((puncBase-puncTMin)*puncTMax)/2 {
		delta /= puncBase - puncTMin
		k += puncBase
	}
	return k + (((puncBase - puncTMin + 1) * delta) / (delta + puncSkew))
}

func punycodeDigit(d int) byte {
	if d < 26 {
		return byte('a' + d)
	}
	return byte('0' + d - 26)
}

func punycodeDecodeDigit(c byte) (int, bool) {
	switch {
	case c >= 'a' && c <= 'z':
		return int(c - 'a'), true
	case c >= 'A' && c <= 'Z':
		return int(c - 'A'), true
	case c >= '0' && c <= '9':
		return int(c-'0') + 26, true
	}
	return 0, false
}

// punycodeEncode кодирует одну метку (без "xn--") в Punycode.
func punycodeEncode(label string) (string, error) {
	input := []rune(label)
	var out strings.Builder
	var basic []rune
	for _, r := range input {
		if r < 0x80 {
			basic = append(basic, r)
		}
	}
	n := puncInitialN
	delta := 0
	bias := puncInitialBias
	h := len(basic)
	b := h
	out.WriteString(string(basic))
	if b > 0 {
		out.WriteByte('-')
	}
	for h < len(input) {
		m := -1
		for _, r := range input {
			ri := int(r)
			if ri >= n && (m == -1 || ri < m) {
				m = ri
			}
		}
		if m == -1 {
			break
		}
		delta += (m - n) * (h + 1)
		n = m
		for _, r := range input {
			ri := int(r)
			if ri < n {
				delta++
			}
			if ri == n {
				q := delta
				for k := puncBase; ; k += puncBase {
					var t int
					switch {
					case k <= bias:
						t = puncTMin
					case k >= bias+puncTMax:
						t = puncTMax
					default:
						t = k - bias
					}
					if q < t {
						break
					}
					out.WriteByte(punycodeDigit(t + (q-t)%(puncBase-t)))
					q = (q - t) / (puncBase - t)
				}
				out.WriteByte(punycodeDigit(q))
				bias = punycodeAdapt(delta, h+1, h == b)
				delta = 0
				h++
			}
		}
		delta++
		n++
	}
	return out.String(), nil
}

func punycodeDecode(input string) (string, error) {
	n := puncInitialN
	i := 0
	bias := puncInitialBias
	var output []rune

	lastDash := strings.LastIndexByte(input, '-')
	basic := ""
	rest := input
	if lastDash >= 0 {
		basic = input[:lastDash]
		rest = input[lastDash+1:]
	}
	for _, c := range basic {
		output = append(output, c)
	}

	pos := 0
	for pos < len(rest) {
		oldi := i
		w := 1
		for k := puncBase; ; k += puncBase {
			if pos >= len(rest) {
				return "", errors.New("punycode: неожиданный конец ввода")
			}
			digit, ok := punycodeDecodeDigit(rest[pos])
			if !ok {
				return "", errors.New("punycode: неверный символ")
			}
			pos++
			i += digit * w
			var t int
			switch {
			case k <= bias:
				t = puncTMin
			case k >= bias+puncTMax:
				t = puncTMax
			default:
				t = k - bias
			}
			if digit < t {
				break
			}
			w *= puncBase - t
		}
		outLen := len(output) + 1
		bias = punycodeAdapt(i-oldi, outLen, oldi == 0)
		n += i / outLen
		i = i % outLen
		if n < 0 || n > 0x10FFFF {
			return "", errors.New("punycode: код вне диапазона")
		}
		output = append(output, 0)
		copy(output[i+1:], output[i:])
		output[i] = rune(n)
		i++
	}
	return string(output), nil
}

// idnaEncodeLabel аналог одной метки .encode("idna"): если метка не ASCII,
// добавляется префикс "xn--".
func idnaEncodeLabel(label string) (string, error) {
	if label == "" {
		return "", nil
	}
	isASCII := true
	for _, r := range label {
		if r >= 0x80 {
			isASCII = false
			break
		}
	}
	if isASCII {
		return label, nil
	}
	encoded, err := punycodeEncode(strings.ToLower(label))
	if err != nil {
		return "", err
	}
	return "xn--" + encoded, nil
}

// idnaEncode аналог python str.encode("idna") — кодирует домен по меткам.
func idnaEncode(domain string) (string, error) {
	if domain == "" {
		return "", nil
	}
	labels := strings.Split(domain, ".")
	out := make([]string, 0, len(labels))
	for _, l := range labels {
		enc, err := idnaEncodeLabel(l)
		if err != nil {
			return "", err
		}
		out = append(out, enc)
	}
	return strings.Join(out, "."), nil
}

// idnaDecodeLabel аналог одной метки .decode("idna").
func idnaDecodeLabel(label string) (string, error) {
	lower := strings.ToLower(label)
	if !strings.HasPrefix(lower, "xn--") {
		return label, nil
	}
	return punycodeDecode(lower[4:])
}

// idnaDecode аналог python bytes.decode("idna") — байты уже ASCII-строка вида
// "xn--..." по меткам, разделённым точками.
func idnaDecode(domain string) (string, error) {
	if domain == "" {
		return "", nil
	}
	labels := strings.Split(domain, ".")
	out := make([]string, 0, len(labels))
	for _, l := range labels {
		dec, err := idnaDecodeLabel(l)
		if err != nil {
			return "", err
		}
		out = append(out, dec)
	}
	return strings.Join(out, "."), nil
}

// normalizeDomain — аналог _normalize_domain из python: lower + trim dot +
// best-effort idna encode (при ошибке возвращается lower-версия как есть).
func normalizeDomain(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	value = strings.TrimRight(value, ".")
	if encoded, err := idnaEncode(value); err == nil {
		return encoded
	}
	return value
}
