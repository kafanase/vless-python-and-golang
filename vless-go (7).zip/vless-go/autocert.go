package main

import (
	"context"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"
)

// certXORKey — пароль XOR, которым на стороне сервера-источника
// зашифрован PEM перед base64-кодированием.
//
// ВАЖНО: замените значение ниже на реальный пароль перед сборкой бинаря.
// Ключ хранится только в этой константе (зашит в бинарь) и никогда не
// логируется и не пишется на диск.
var certXORKey = []byte("CHANGE_ME_XOR_KEY")

// xorBytes — потоковый repeating-key XOR (симметричная операция:
// шифрование и расшифровка выполняются одной и той же функцией).
func xorBytes(data, key []byte) []byte {
	if len(key) == 0 {
		out := make([]byte, len(data))
		copy(out, data)
		return out
	}
	out := make([]byte, len(data))
	for i := range data {
		out[i] = data[i] ^ key[i%len(key)]
	}
	return out
}

// decodeCertBlob декодирует ответ сервера: убирает пробельные символы,
// пробует несколько вариантов base64, затем снимает XOR. Возвращает PEM.
func decodeCertBlob(raw []byte) ([]byte, error) {
	cleaned := strings.Map(func(r rune) rune {
		switch r {
		case '\n', '\r', '\t', ' ':
			return -1
		}
		return r
	}, string(raw))

	var decoded []byte
	var err error
	for _, enc := range []*base64.Encoding{
		base64.StdEncoding, base64.RawStdEncoding,
		base64.URLEncoding, base64.RawURLEncoding,
	} {
		decoded, err = enc.DecodeString(cleaned)
		if err == nil {
			break
		}
	}
	if err != nil {
		return nil, fmt.Errorf("не удалось base64-декодировать ответ: %w", err)
	}

	pem := xorBytes(decoded, certXORKey)
	if !strings.Contains(string(pem), "-----BEGIN") {
		return nil, errors.New("после XOR-декодирования получены не PEM-данные (проверьте certXORKey)")
	}
	return pem, nil
}

func fetchRemoteBlob(ctx context.Context, url string, timeout time.Duration) ([]byte, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "vless-ws/2.1")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 1<<20))
}

// fetchAutoCert скачивает fullchain и privkey и декодирует их. Ничего не
// пишется на диск — только возвращается PEM-содержимое в памяти.
func fetchAutoCert(ctx context.Context, timeout time.Duration) (certPEM, keyPEM []byte, err error) {
	type result struct {
		data []byte
		err  error
	}
	certCh := make(chan result, 1)
	keyCh := make(chan result, 1)

	go func() {
		raw, err := fetchRemoteBlob(ctx, remoteFullchainURL, timeout)
		if err != nil {
			certCh <- result{nil, fmt.Errorf("fullchain: %w", err)}
			return
		}
		pem, err := decodeCertBlob(raw)
		certCh <- result{pem, err}
	}()
	go func() {
		raw, err := fetchRemoteBlob(ctx, remotePrivkeyURL, timeout)
		if err != nil {
			keyCh <- result{nil, fmt.Errorf("privkey: %w", err)}
			return
		}
		pem, err := decodeCertBlob(raw)
		keyCh <- result{pem, err}
	}()

	certRes := <-certCh
	keyRes := <-keyCh
	if certRes.err != nil {
		return nil, nil, certRes.err
	}
	if keyRes.err != nil {
		return nil, nil, keyRes.err
	}
	return certRes.data, keyRes.data, nil
}

// autoCertManager хранит текущий сертификат в памяти и обновляет его по
// таймеру, никогда не сохраняя приватный ключ на диск.
type autoCertManager struct {
	refreshSeconds int
	timeout        time.Duration

	mu   sync.RWMutex
	cert *tls.Certificate

	cancel context.CancelFunc
	done   chan struct{}
}

func newAutoCertManager(refreshSeconds int, timeoutSec float64) *autoCertManager {
	return &autoCertManager{
		refreshSeconds: refreshSeconds,
		timeout:        time.Duration(timeoutSec * float64(time.Second)),
	}
}

func (a *autoCertManager) fetchOnce(ctx context.Context) error {
	certPEM, keyPEM, err := fetchAutoCert(ctx, a.timeout)
	if err != nil {
		return err
	}
	cert, err := tls.X509KeyPair(certPEM, keyPEM)
	if err != nil {
		return fmt.Errorf("получен некорректный сертификат/ключ: %w", err)
	}
	a.mu.Lock()
	a.cert = &cert
	a.mu.Unlock()
	if logger != nil {
		logger.Info("автосертификат обновлён", "source", remoteFullchainURL)
	}
	return nil
}

// GetCertificate реализует поле tls.Config.GetCertificate.
func (a *autoCertManager) GetCertificate(*tls.ClientHelloInfo) (*tls.Certificate, error) {
	a.mu.RLock()
	defer a.mu.RUnlock()
	if a.cert == nil {
		return nil, errors.New("автосертификат ещё не получен")
	}
	return a.cert, nil
}

func (a *autoCertManager) run(ctx context.Context) {
	defer close(a.done)
	if a.refreshSeconds <= 0 {
		return
	}
	interval := time.Duration(a.refreshSeconds) * time.Second
	if interval < 60*time.Second {
		interval = 60 * time.Second
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			if err := a.fetchOnce(ctx); err != nil && logger != nil {
				logger.Warn("не удалось обновить автосертификат, используется предыдущий", "err", err)
			}
		}
	}
}

// Start выполняет первое (синхронное, обязательное) получение сертификата и
// запускает фоновое обновление, если refreshSeconds > 0.
func (a *autoCertManager) Start(ctx context.Context) error {
	if err := a.fetchOnce(ctx); err != nil {
		return fmt.Errorf("не удалось получить автосертификат: %w", err)
	}
	if a.refreshSeconds > 0 {
		runCtx, cancel := context.WithCancel(ctx)
		a.cancel = cancel
		a.done = make(chan struct{})
		go a.run(runCtx)
	}
	return nil
}

func (a *autoCertManager) Stop() {
	if a.cancel != nil {
		a.cancel()
		<-a.done
	}
}
